from constants_cytex import *
from UserManagement.user_creation import UserCreate
from UserManagement.user_group import UserGroup
from UserManagement.config import Config
import traceback
import os
from user_input import user_requirement


class UserManagement():

    def main(self) -> None:
        """
        This function is responsible for performing all tasks because in this we call the
        functionality that we need to automate if its function is already prepared and 
        functioning properly.
        """
        try:
            self.driver = None
            print(
                "\n**********************ENTERED USER MANAGEMENT*************************************\n")

            if user_requirement["User_Management"]["all"]:
                print("entered allllllll")
                "This will perform all functionalities of User Management sub modules"
                self.user_group = UserGroup(self.driver)
                self.driver = self.user_group.main()
                self.user_create = UserCreate(self.driver)
                self.driver = self.user_create.main()
                self.config = Config(self.driver)
                self.config.main()
                # os.remove('lockfile.lock')
            else:

                if user_requirement["User_Management"]["create_user"]:
                    "User selects User Create"
                    # This will add create user credentials
                    self.user_create = UserCreate(self.driver)
                    self.driver = self.user_create.main()

                if user_requirement["User_Management"]["user_group"]:
                    "User selects User Group"
                    self.user_group = UserGroup(self.driver)
                    self.driver = self.user_group.main()

                if user_requirement["User_Management"]["config"]:
                    "User selects Configuartion"
                    self.config = Config(self.driver)
                    self.driver = self.config.main()

            return self.driver
            # else:
            #     "User entered in this body if entered random key"
            #     print("please enter the above mentioned keys")

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
