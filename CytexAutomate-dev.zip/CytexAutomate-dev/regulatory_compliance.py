from constants_cytex import *
from common_functionalities import CommonUsed
from RegulatoryCompliances.nist import NIST
from RegulatoryCompliances.iso import ISO
from RegulatoryCompliances.nist_sp import NIST_SP
from RegulatoryCompliances.ofdss import OFDSS
from RegulatoryCompliances.soc2 import SOC2
from RegulatoryCompliances.audify import Audify
from RegulatoryCompliances.audify_framework import AudifyFramework
import traceback
from user_input import user_requirement

class RegulatoryCompliance():
    def __init__(self, driver=None) -> None:
        # self.lock_file_path = 'lockfile.lock'
        if driver is not None:
            self.driver = driver
            # self.common = CommonUsed(driver)
        else:
            self.driver = None
            # self.common = CommonUsed()
        # self.username = self.common.username

    def main(self) -> None:
        """
        This function is responsible for performing all tasks because in this we call the
        functionality that we need to automate if its function is already prepared and 
        functioning properly.
        """
        try:
            print(
                "\n**********************ENTERED REGULATORY COMPLIANCE*************************************\n")

            if user_requirement["Regulatory_Compliance"]["all"]:
                "This will perform all functionalities of User Management sub modules"
                pass
            elif user_requirement["Regulatory_Compliance"]["nist"]:
                "User selects User Create"
                # This will add create user credentials
                self.nist = NIST(self.driver)
                self.nist.main()
            elif user_requirement["Regulatory_Compliance"]["iso"]:
                "User selects User Create"
                
                self.iso = ISO(self.driver)
                self.iso.main()
            elif user_requirement["Regulatory_Compliance"]["nist_800"]:
                "User selects User Create"
                self.nist_sp = NIST_SP(self.driver)
                self.nist_sp.main()
            elif user_requirement["Regulatory_Compliance"]["ofdss"]:
                self.ofdss = OFDSS(self.driver)
                self.ofdss.main()
            elif user_requirement["Regulatory_Compliance"]["soc2"]:
                self.soc2 = SOC2(self.driver)
                self.soc2.main()
            elif user_requirement["Regulatory_Compliance"]["audify"]:
                self.audify = Audify(self.driver)
                self.audify.main()
            elif user_requirement["Regulatory_Compliance"]["audify_framework"]:
                self.audify_framework = AudifyFramework(self.driver)
                self.audify_framework.main()
            else:
                "User entered in this body if entered random key"
                print("please enter the above mentioned keys")

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
