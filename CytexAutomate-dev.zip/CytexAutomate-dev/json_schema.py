import json
import jsonschema

# Define the JSON Schema
schema = {
    "type": "object",
    "properties": {
        "User_Management": {'start': {"type": bool}, 'create_user': {"type": bool}, 'user_group': {"type": bool}, 'config': {"type": bool}},
        "Regulatory_Compliance": {'start': {"type": bool}},
        "All_Modules": {"type": dict}
    },
    "required": ["User_Management", "Regulatory_Compliance", "All_Modules"]
}

def validating_user_input(json_data):
    data = json.loads(json_data)

    # Validate the JSON data against the JSON Schema
    try:
        jsonschema.validate(data, schema)
        print("JSON data is valid.")
    except jsonschema.exceptions.ValidationError as e:
        print("JSON data is invalid:", e)