import traceback
from user_management import UserManagement
from regulatory_compliance import RegulatoryCompliance
import os
from user_input import user_requirement
import time
# from json_schema import validating_user_input
import json
from constants_cytex import *


class Cytex_Automate():
    def __init__(self) -> None:
        self.user_management = UserManagement()
        pass

    def main(self) -> None:
        """
        This function is responsible for performing all tasks because in this we call the
        functionality that we need to automate if its function is already prepared and 
        functioning properly.
        """
        try:
            # validating_user_input(user_requirement)
            self.check_user_requirement()

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )

    def check_user_requirement(self):
        self.driver = None
        self.regulatory_compliance = None
        print("this is file name    :   ", RESULT_FILE_NAME)
        print("this is file name    :   ", type(RESULT_FILE_NAME))
        
        with open(RESULT_FILE_NAME, 'w') as file:
            json.dump({}, file, indent=4)
        print("result file created")
        
        if user_requirement["All_Modules"]:
            print("entered")
            self.driver = self.user_management.main()
            time.sleep(3)
            print("this is the driver", self.driver)
            self.regulatory_compliance = RegulatoryCompliance(self.driver)
            self.driver = self.regulatory_compliance.main()
            os.remove('lockfile.lock')

        else:
            if user_requirement["User_Management"]["start"]:
                "enter in User Management"
                self.driver = self.user_management.main()

            if user_requirement["Regulatory_Compliance"]["start"]:
                "Regulatory Compilance in progress"
                self.regulatory_compliance = RegulatoryCompliance(self.driver)
                self.driver = self.regulatory_compliance.main()
            os.remove('lockfile.lock')


if __name__ == "__main__":
    obj = Cytex_Automate()
    obj.main()
