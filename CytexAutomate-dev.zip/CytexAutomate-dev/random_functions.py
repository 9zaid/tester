import random


def generate_username():
    """Generates a random username"""
    names = random.choice(
        ["Jordan", "Bruce", "Laila", "Riley", "Jorge", "Emerson"])
    last_names = random.choice(
        ["Ivan", "Scott", "Tommy", "Stuart", "Sebastian", "Ernest"])
    number = random.randint(100, 999)
    username = f"{names}{last_names}{number}"
    print("this is the username :   ", username)
    return username