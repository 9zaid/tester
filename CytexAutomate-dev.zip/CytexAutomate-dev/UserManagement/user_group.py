import time
import traceback
from constants_cytex import *
from selenium.webdriver.support import expected_conditions as EC
from common_functionalities import CommonUsed
from selenium.webdriver.common.by import By
import json
from datetime import datetime


class UserGroup():
    def __init__(self, driver=None) -> None:
        # self.common = CommonUsed()
        if driver is not None:
            self.driver = driver
            self.common = CommonUsed(driver)
        else:
            self.driver = None
            self.common = CommonUsed()
        # self.wait = None

    def main(self):
        """
        In this we are working on user group module in which we are testing
        -> creating new user group
        -> checking search
        -> checking filter
        -> matching above records and below total records
        """
        try:
            self.lock_file_path = 'lockfile.lock'

            status = self.check_status()
            module_name = "User Management"
            if status != "Already Created":
                self.common.start()
                self.driver = self.common.driver
                self.common.wait.until(
                    EC.element_to_be_clickable((By.NAME, "text")))
                # This function login user when passed credentials
                self.common.login_page(login_user_list[0])

            # This will redirect to create user page
            time.sleep(3)
            self.common.user_mgmt_path_sub_modules(
                Element_User_Mgmt, User_Mgmt_sub_Components["user_group"], module_name, "user_group")
            self.create_user_group()

            return self.driver
        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )

    def create_user_group(self):
        try:
            # this both is used in creating group
            self.group_name = CREATE_USER_GROUP["group_name"]
            self.group_desc = CREATE_USER_GROUP["group_desc"]
            
            # read json_file
            with open(RESULT_FILE_NAME, 'r') as file:
                self.existing_data = json.load(file)
                
            new_data = {}
            key = "UserManagement"
            new_data = {
                "user_group": {
                    "id":None,
                    "group_name": self.group_name,
                    "create": None,
                    "filter": None,
                    "search": None,
                    "match_rows_and_number": None,
                    "timestamp": datetime.now().strftime("%d-%m-%Y_%H:%M:%S"),
                    "error": []
                    }
            }
            if key in self.existing_data:
                self.existing_data["UserManagement"].update(new_data)
            else:
                self.existing_data["UserManagement"] = new_data
            print("entered user group")
            print(self.existing_data)
            with open(RESULT_FILE_NAME, 'w') as file:
                json.dump(self.existing_data, file, indent=4)

            if self.driver.current_url == USER_GROUP_PAGE_URL:
                print(
                    "********************************User Group*********************************")

                _, total_records = self.common.check_records(3, self.existing_data, "user_group")

                self.providing_user_group_credentials(CREATE_GROUP_ELEMENTS)
                time.sleep(3)
                records_after_create = self.driver.execute_script(
                    "return document.querySelector('tbody').querySelectorAll('input')")
                print(
                    "this is the total records written in line which is below table : ", total_records)

                self.existing_data = self.common.read_result()
                if len(records_after_create)/3 - total_records == 1:
                    self.existing_data["UserManagement"]["user_group"]["create"] = "successfull"
                    self.common.update_result(self.existing_data)
                    print("This shows that new user is created successfully")

                else:
                    self.existing_data["UserManagement"]["user_group"]["create"] = "failed"
                    self.common.update_result(self.existing_data)
                    print("User group is not created")

                # This below function used to perform search and result must be in boolean
                self.common.check_filter(records_after_create[0].get_attribute(
                    "value"), "create_td", "user_group")
                time.sleep(2)
                self.common.check_search(records_after_create[0].get_attribute(
                    "value"), 3, "user_group")
                time.sleep(4)
            else:
                print("URL is not matched")
        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            print("Error in create user group function")

    def providing_user_group_credentials(self,create_group):
        """
        This function is used to create user group first it clicks on the new group which pops
        up the user_group form then we will fill it by providing credentials and marking all
        checkboxes after that we submit the details which will create new user group
        """
        try:
            time.sleep(4)

            # this clicks the button with that id which opens the form of user groups
            self.driver.find_element(
                By.CSS_SELECTOR, 'button[id="create_group_btn"]').click()

            # this will wait until Group_name is clickable
            self.common.wait.until(EC.element_to_be_clickable(
                (By.CSS_SELECTOR, f'div.modal-body input[placeholder="{create_group["group_name"]}"]')))
            group_name = self.driver.find_element(
                By.CSS_SELECTOR, f'div.modal-body input[placeholder="{create_group["group_name"]}"]')
            group_name.send_keys(self.group_name)
            time.sleep(2)

            group_desc = self.driver.find_element(
                By.CSS_SELECTOR, f'div.modal-body input[placeholder="{create_group["group_desc"]}"]')
            group_desc.send_keys(self.group_desc)

            # This will mark all checkboxes
            for i in range(1,5):
                self.driver.execute_script(f'document.querySelector("#add_workflow > span:nth-child({i}) > input").click()')
            self.driver.execute_script('document.querySelector("#dropbox_span > input").click()')
            self.driver.execute_script('document.querySelector("#google_workspace_span > input").click()')
            self.driver.execute_script('document.querySelector("#microsoft_azure_span > input").click()')

            # This will click submit after completing create_user_group
            self.driver.find_element(
                By.CSS_SELECTOR, f'input[id="{create_group["submit_btn"]}"]').click()
            time.sleep(4)

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            print("Error in providing create user group credentials")

    def check_status(self):
        "This function checks that lock file is present or not which means browser is running"
        if os.path.exists(self.lock_file_path):
            return "Already Created"
        else:
            # Create lock file
            open(self.lock_file_path, 'w').close()
            return "Not Created"
