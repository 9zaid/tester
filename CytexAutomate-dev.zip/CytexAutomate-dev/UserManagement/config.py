import time
import traceback
from constants_cytex import *
from selenium.webdriver.support import expected_conditions as EC
from common_functionalities import CommonUsed
from selenium.webdriver.common.by import By
import json
from datetime import datetime


class Config():
    def __init__(self, driver=None) -> None:
        self.lock_file_path = 'lockfile.lock'
        if driver is not None:
            self.driver = driver
            self.common = CommonUsed(driver)
        else:
            self.driver = None
            self.common = CommonUsed()

    def main(self):
        try:
            status = self.check_status()
            module_name = "User Management"
            if status != "Already Created":
                self.common.start()
                self.driver = self.common.driver
                self.common.wait.until(
                    EC.element_to_be_clickable((By.NAME, "text")))
                # This function login user when passed credentials
                self.common.login_page(login_user_list[0])

            # This will redirect to create user page
            time.sleep(3)
            self.common.user_mgmt_path_sub_modules(
                Element_User_Mgmt, User_Mgmt_sub_Components["config"], module_name, "config")

            self.common.wait.until(EC.element_to_be_clickable(
                (By.CSS_SELECTOR, 'div#tableWidth')))
            print("calling configuration")
            self.configuration()

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )

    def configuration(self):
        try:
            print("entered config")
            with open(RESULT_FILE_NAME, 'r') as file:
                self.existing_data = json.load(file)
            mode_name = "user"
            self.username = self.existing_data["UserManagement"]["user"]["username"]
            time.sleep(2)
            if self.common.driver.current_url == CONFIGURATION_PAGE_URL:
                print(
                    "\n\n********************************User Details*********************************")
                table_rows, _ = self.common.check_records(7,self.existing_data, mode_name)

                for i in range(len(table_rows)):
                    if str(table_rows[i].get_attribute("value")) == self.username:
                        print(
                            "\nSuccessfully created new user with username  :   ", self.username)
                        check = True
                        break
                self.first_name = "Brady"            
                self.common.check_filter(
                    self.first_name, "create_td", mode_name)
                self.existing_data = self.common.read_result()
                time.sleep(2)
                search = self.common.check_search(self.username, 7, mode_name)
                print("this is returning from search")
                print(search)
                time.sleep(3)
                if search==True:
                    print("entered in search true")
                    self.existing_data["UserManagement"][mode_name]["search"] = "successfull"
                    self.existing_data["UserManagement"][mode_name]["create"] = "successfull"
                    self.common.update_result(self.existing_data)
                else:
                    self.existing_data["UserManagement"][mode_name]["create"] = "failed"
                    self.common.update_result(self.existing_data)
                        
                # now deleting created user
                # self.delete_user()
                # search = self.common.check_search(self.username, 7, mode_name)
                
                # # verifying if it is deleted or not
                # if search == False:
                #     self.existing_data["UserManagement"][mode_name]["delete"] = "successfull"
                # else:
                #     self.existing_data["UserManagement"][mode_name]["delete"] = "failed"
                    
                return self.common.driver
        except:
            self.existing_data[mode_name]["error"].append("error in configuration page")
            print("error in configuration page")
            pass
    
    def delete_user(self):
        try:
            self.driver.execute_script('document.querySelector("#create_td > tbody > tr > td:nth-child(10) > ul > li > a > button").click()')
            time.sleep(1)
            self.driver.execute_script('document.querySelector("body > ul > li:nth-child(1) > a").click()')
            time.sleep(1)
            self.driver.execute_script('document.querySelector("body > div.sweet-alert.showSweetAlert.visible > div.sa-button-container > div > button").click()')
            time.sleep(1)
        except:
            print("error in delete user")
            pass
    
    def check_status(self):
        "This function checks that lock file is present or not which means browser is running"
        if os.path.exists(self.lock_file_path):
            return "Already Created"
        else:
            # Create lock file
            open(self.lock_file_path, 'w').close()
            return "Not Created"
