import time
import traceback
from constants_cytex import *
from selenium.webdriver.support import expected_conditions as EC
from common_functionalities import CommonUsed
from selenium.webdriver.common.by import By
import os
from user_input import create_user
import json
from datetime import datetime
from user_input import *


class UserCreate():
    def __init__(self, driver=None) -> None:
        # self.common = CommonUsed()
        
        if driver is not None:
            self.driver = driver
            self.common = CommonUsed(driver)
        else:
            self.driver = None
            self.common = CommonUsed()
        self.username = self.common.username

    def main(self):
        try:
            self.lock_file_path = 'lockfile.lock'

            status = self.check_status()
            module_name = "User Management"

            # This will redirect to create user page
            if status != "Already Created":
                self.common.start()
                self.driver = self.common.driver
                self.common.wait.until(
                    EC.element_to_be_clickable((By.NAME, "text")))
                # This function login user when passed credentials
                self.common.login_page(login_user_list[0])
            print("tag 3")
            time.sleep(3)
            self.common.user_mgmt_path_sub_modules(
                Element_User_Mgmt, User_Mgmt_sub_Components["create_user"], module_name, "create_user")
            print("tag 4")

            print("this is the username     ", self.common.username)
            self.create_user(
                CREATE_USER[0], CREATE_USER_BY_PLACEHOLDER)
            time.sleep(3)
            return self.driver
        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            print("Error in create user page")

    def create_user(self, user: dict, ele_by_placeholder: dict) -> None:
        """
        This function is just used to create_user by passing user credentials

        user -> It is the user credentials that is passed to create
        ele_by_placeholder -> This contains input elements placeholders which are responsible
         to find input tag which needs to filled

        """
        try:
            with open(RESULT_FILE_NAME, 'r') as file:
                self.existing_data = json.load(file)
            key = "UserManagement"
            new_data = {}
            new_data = {
            "user": {
                "id":None,
                "username": self.username,
                "create": None,
                "filter": None,
                "search": None,
                "match_rows_and_number": None,
                "delete": None,
                "timestamp": datetime.now().strftime("%d-%m-%Y_%H:%M:%S"),
                "error": []
                }
            }
            if key in self.existing_data:
                self.existing_data["UserManagement"].update(new_data)
            else:
                self.existing_data["UserManagement"] = new_data
            print("entered create user")
            print(self.existing_data)
            with open(RESULT_FILE_NAME, 'w') as file:
                json.dump(self.existing_data, file, indent=4)
            
            
            if self.driver.current_url == CREATE_USER_PAGE_URL:
                print(
                    "\n\n********************************Create User*********************************")
                self.first_name = user["first_name"]

                self.driver.execute_script(
                    f'document.querySelector(\'[placeholder="{ele_by_placeholder["first_name"]}"]\').setAttribute("value", "{self.first_name}")')
                self.driver.execute_script(
                    f'document.querySelector(\'[placeholder="{ele_by_placeholder["last_name"]}"]\').setAttribute("value", "{user["last_name"]}")')
                self.driver.execute_script(
                    f'document.querySelector(\'[placeholder="{ele_by_placeholder["username"]}"]\').setAttribute("value", "{self.username}")')
                self.driver.execute_script(
                    f'document.querySelector(\'[placeholder="{ele_by_placeholder["password"]}"]\').setAttribute("value", "{user["password"]}")')
                self.driver.execute_script(
                    f'document.querySelector(\'[placeholder="{ele_by_placeholder["confirm_password"]}"]\').setAttribute("value", "{ user["confirm_password"]}")')
                self.driver.execute_script(
                    f'document.querySelector(\'[placeholder="{ele_by_placeholder["email"]}"]\').setAttribute("value", "{user["email"]}")')
                self.driver.execute_script(
                    f'document.querySelector(\'[placeholder="{ele_by_placeholder["functional_area"]}"]\').setAttribute("value", "{user["functional_area"]}")')
                time.sleep(5)

                index_group = 0
                self.driver.execute_script(
                    'document.querySelector(\'[data-id="user_group"]\').click()')
                time.sleep(2)
                self.driver.execute_script(
                    'document.querySelector(\'ul.dropdown-menu.inner\').getElementsByTagName("li").length')
                self.driver.execute_script(
                    'document.querySelector(\'[tabindex="{}"]\').click()'.format(index_group))
                time.sleep(2)
                self.allowed_modules(ALLOWED_MODULES_BY_ID)

                time.sleep(2)

                # This will mark write check box
                self.driver.execute_script(
                    'document.querySelector(\'#write_access\').click()')

                time.sleep(2)
                self.driver.find_element(
                    By.NAME, "signuplastname").click()
                time.sleep(2)
                self.driver.execute_script('document.querySelector(\'[placeholder="{}"]\').click()'.format(
                    ele_by_placeholder["first_name"]))
                self.common.wait.until(EC.element_to_be_clickable(
                    (By.ID, "submit-form")))
                self.driver.execute_script(
                    'document.querySelector(\'[name="signupsubmit"]\').click()')
                print("User credentials is passed and submitted")
            else:
                print("URL is not matched")
        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            self.existing_data["UserManagement"]["user"]["error"].append("")
            print("Error in create user page")

    def allowed_modules(self, attr) -> None:
        """
        This function redirects that sub function which access wants to allow for new 
        user. If want to allow all modules then its separate function is also presenet.

        attr -> It contains all data-id that is responsible to find allowing modules
        """
        try:
            # This will open allowed modules bar
            self.driver.execute_script(
                f'document.querySelector(\'[placeholder="Allowed modules *"]\').click()')
            
            time.sleep(1)

            if create_user["all"]:
                "Network Traffic"
                self.all_allowed_modules(attr)
            else:
                "User entered in this body if entered random key"
                print("You entered not a boolean input in user input file")
                # This will open allowed modules bar
                self.driver.execute_script(
                    f'document.querySelector(\'[placeholder="Allowed modules *"]\').click()')

                if create_user["network_traffic"]:
                    "Cloud Apps"
                    self.allow_modules_for_cloud_apps(attr["network_traffic"])

                if create_user["cloud_apps"]:
                    "Cloud Apps"
                    self.allow_modules_for_cloud_apps(attr["cloud_apps"])

                if create_user["data_supply_chain"]:
                    "Data Supply Chain"
                    self.allowed_modules_data_supply(attr["data_supply_chain"])
                if create_user["user_management"]:
                    "Data Supply Chain"
                    self.allowed_modules_data_supply(attr["user_management"])
                    
                if create_user["cloud_security_posture"]:
                    "Data Supply Chain"
                    self.allowed_modules_data_supply(attr["cloud_security_posture"])
                if create_user["cytex_secure"]:
                    "Data Supply Chain"
                    self.allowed_modules_data_supply(attr["cytex_secure"])
                if create_user["reports"]:
                    "Data Supply Chain"
                    self.allowed_modules_data_supply(attr["reports"])
                if create_user["configuration"]:
                    "Data Supply Chain"
                    self.allowed_modules_data_supply(attr["configuration"])
                if create_user["phishing"]:
                    "Data Supply Chain"
                    self.allowed_modules_data_supply(attr["phishing"])
                if create_user["regulatory"]:
                    "Data Supply Chain"
                    self.allowed_modules_data_supply(attr["regulatory"])
                if create_user["system_integration"]:
                    "Data Supply Chain"
                    self.allowed_modules_data_supply(attr["system_integration"])
                if create_user["edr"]:
                    "Data Supply Chain"
                    self.allowed_modules_data_supply(attr["edr"])
                if create_user["syslog"]:
                    "Data Supply Chain"
                    self.allowed_modules_data_supply(attr["syslog"])
                    time.sleep(1)


        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )

    def allow_modules_for_network_traffic(self, id: str) -> None:
        """
        This will allow only cloud apps
        """
        try:

            # This selects network_traffic check box
            self.driver.execute_script(
                f'document.querySelector(\'[data-id={id}]\').click()')
            time.sleep(2)

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )

    def allow_modules_for_cloud_apps(self, id: str) -> None:
        """
        This will allow only cloud apps
        """
        try:
            

            # This selects cloud_apps check box
            self.driver.execute_script(
                f'document.querySelector(\'[data-id={id}]\').click()')
            time.sleep(2)

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )

    def allowed_modules_data_supply(self, id: str):
        """
        This will allow all netwok traffic and data supply chain
        """
        try:
            # This selects data_supply_chain check box
            self.driver.execute_script(
                f'document.querySelector(\'[data-id={id}]\').click()')

        except Exception as e:
            print("*************** error in allowed modules ********************")
            print(
                e.__traceback__.tb_lineno,  # 2
            )

    def allowed_modules_for_user_mgmt(self, id: str):
        """
        This will allow all modules
        """
        try:
            # This selects user_management check box
            self.driver.execute_script(
                f'document.querySelector(\'[data-id={id}]\').click()')
            time.sleep(2)

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )

    def all_allowed_modules(self, attr: dict):
        """
        This will allow all modules
        """
        try:
            # All allowed modules

            # This will open allowed modules bar
            self.driver.execute_script(
                'document.querySelector(\'[placeholder="Allowed modules *"]\').click()')
            time.sleep(2)

            # This selects network_traffic check box
            self.driver.execute_script(
                f'document.querySelector(\'[data-id={attr["network_traffic"]}]\').click()')

            # This selects cloud_apps check box
            self.driver.execute_script(
                f'document.querySelector(\'[data-id={attr["cloud_apps"]}]\').click()')

            # This selects data_supply_chain check box
            self.driver.execute_script(
                f'document.querySelector(\'[data-id={attr["data_supply_chain"]}]\').click()')

            # This selects user_management check box
            self.driver.execute_script(
                f'document.querySelector(\'[data-id={attr["user_management"]}]\').click()')

            # This selects cloud_security_posture check box
            self.driver.execute_script(
                f'document.querySelector(\'[data-id={attr["cloud_security_posture"]}]\').click()')

            # This selects cytex_secure check box
            self.driver.execute_script(
                f'document.querySelector(\'[data-id={attr["cytex_secure"]}]\').click()')

            # This selects reports check box
            self.driver.execute_script(
                f'document.querySelector(\'[data-id={attr["reports"]}]\').click()')

            # This selects configuration check box
            self.driver.execute_script(
                f'document.querySelector(\'[data-id={attr["configuration"]}]\').click()')

            # This selects phishing check box
            self.driver.execute_script(
                f'document.querySelector(\'[data-id={attr["phishing"]}]\').click()')

            # This selects regulatory check box
            self.driver.execute_script(
                f'document.querySelector(\'[data-id={attr["regulatory"]}]\').click()')

            # This selects system_integration check box
            self.driver.execute_script(
                f'document.querySelector(\'[data-id={attr["system_integration"]}]\').click()')
            time.sleep(2)

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )

    def check_status(self):
        "This function checks that lock file is present or not which means browser is running"
        if os.path.exists(self.lock_file_path):
            return "Already Created"
        else:
            # Create lock file
            open(self.lock_file_path, 'w').close()
            return "Not Created"
