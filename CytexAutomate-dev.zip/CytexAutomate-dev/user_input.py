
user_requirement = {"User_Management": {'start': False, 'create_user': True, 'user_group':  True, 'config': True, 'all':   False}, "Regulatory_Compliance": {'start': True, 'nist': False, 'iso': False, 'nist_800':False, 'ofdss': False, "soc2": False, "audify": False, "audify_framework": True,'all': False}, "All_Modules": False}


audify_control = {
    "framework": False, "group": False, "category": False
}

create_user = {"all": False, "network_traffic": True,
               "cloud_apps": True, "data_supply_chain": True,"user_management": True,
               "cloud_security_posture": True, "cytex_secure": True,"reports": True,
               "configuration": True, "phishing": True,"regulatory": True, "system_integration": True,"edr": True,
               "syslog": True}
