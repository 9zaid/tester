from constants_cytex import *
import time
from selenium.webdriver.common.by import By
import traceback
from selenium.webdriver.support import expected_conditions as EC
import os
from datetime import datetime, timedelta, date
from selenium.webdriver.common.keys import Keys
import random


class Regulatory_Compliance_Common:
    def __init__(
        self, wait=None, driver=None, path=None, path_docs=None, name=""
    ) -> None:
        if driver is not None:
            self.driver = driver
            self.path = path
            self.path_docs = path_docs
            self.wait = wait
            self.name = name

        else:
            self.driver = None
            self.mod_self = None
            self.path = None
            self.docs_path = None
            self.wait = None
            self.name = ""

    def attach_policy_doc(self, module_name=None, sub_mod=""):
        """
        This is the first form that will be filled without file
        """
        try:
            print("entered in attach policy doc")
            # wait until policy option loads properly
            self.wait.until(
                EC.element_to_be_clickable(
                    (By.CSS_SELECTOR, "button[data-id='policyDocuments']")
                )
            )

            # clicks on policy document button
            self.driver.find_element(
                By.CSS_SELECTOR, "button[data-id='policyDocuments']"
            ).click()
            time.sleep(2)

            # selects one option fron dropdown
            self.driver.find_element(
                By.CSS_SELECTOR, "ul.dropdown-menu.inner li[data-original-index='0'] a"
            ).click()

            # again selects dropdown to close it
            self.driver.find_element(
                By.CSS_SELECTOR, "button[data-id='policyDocuments']"
            ).click()

            # save the policy document
            self.driver.find_element(
                By.CSS_SELECTOR, "button#addPoliciesToControl"
            ).click()
            time.sleep(2)

            # wait to properly attach policy doc
            self.wait.until(
                EC.visibility_of_element_located(
                    (By.CSS_SELECTOR, "#create_tdd > tbody > tr")
                )
            )
            # download policy document
            self.driver.execute_script(
                'document.querySelector("#create_tdd > tbody > tr > td:nth-child(4) > ul > li > a > button").click()'
            )
            self.driver.execute_script('document.querySelector("#dwnldLnk").click()')
            print("pollicy document successfully downloaded")
            time.sleep(1)

            # upload policy
            self.upload_policy()
        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            print("error in attach_policy_doc")

    def upload_policy(self):
        try:
            # print(10 * "*", "entered upload policy doc", 10 * "*")
            # this will click on upload file
            self.driver.execute_script(
                'document.querySelector("#editdefaultBadge > div:nth-child(1) > a").click()'
            )
            time.sleep(2)

            # Policy Document
            self.policy_document()
            time.sleep(3)

            # Document Library
            self.document_library()
            time.sleep(3)

            # Custom Policy
            self.custom_policy()
            time.sleep(2)
            self.driver.back()
        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            self.driver.back()
            print("Error in upload_policy")

    def policy_document(self):
        try:
            # wait until page loads properly
            self.wait.until(
                EC.element_to_be_clickable(
                    (By.CSS_SELECTOR, "#tab_card > ul > li.active.crsr-pintr-mt--5 > a")
                )
            )
            list_policy = self.driver.find_elements(
                By.CSS_SELECTOR, f"#create_td > tbody > tr"
            )
            for i in range(1, 3):
                file = os.path.join(self.path_docs, f"sample{i}.docx")

                # this will click on one action button
                self.driver.execute_script(
                    f'document.querySelector("#create_td > tbody > tr:nth-child({i+2}) > td:nth-child(3) > ul > li > a > button").click()'
                )
                list_policy[i].find_element(
                    By.CSS_SELECTOR, "td > ul li #file-1"
                ).send_keys(file)
                time.sleep(1)

            print("uploaded file in policy doc")
        except Exception as e:
            print("Error in policy_document")

    def document_library(self):
        try:
            # wait until page loads properly
            self.wait.until(
                EC.element_to_be_clickable(
                    (By.CSS_SELECTOR, "#tab_card > ul > li.active.crsr-pintr-mt--5 > a")
                )
            )
            # this will clicks on document library title
            self.driver.execute_script(
                'document.querySelector("#tab_card > ul > li:nth-child(2) > a").click()'
            )
            time.sleep(2)
            for i in range(1, 3):
                # this will click on one action button
                self.driver.execute_script(
                    f'document.querySelector("#create_tdd > tbody > tr:nth-child({i+2}) > td:nth-child(4) > ul > li > a > button")'
                )

                # selects downloads option
                self.driver.execute_script(
                    f'document.querySelector("#create_tdd > tbody > tr:nth-child({i+2}) > td:nth-child(4) > ul > li #dwnldLnk").click()'
                )
                time.sleep(1)
            print("downloaded document libray files\n")
        except Exception as e:
            print("Error in document_library")

    def custom_policy(self):
        try:
            time.sleep(2)
            custom_file = os.path.join(self.path_docs, "sample3.docx")
            policy_name = "automated_file" + str(random.randint(0, 1000))

            # click on custom policy
            self.driver.execute_script(
                'document.querySelector("#tab_card > ul > li:nth-child(3) > a").click()'
            )
            time.sleep(2)

            # provide policy name
            self.driver.execute_script(
                f'document.querySelector("#policy_name").value = "{policy_name}" '
            )
            time.sleep(2)

            # this will get upload file element
            # print("uploading file custom_policy")

            self.driver.find_element(By.CSS_SELECTOR, "#user_policy").send_keys(
                custom_file
            )
            time.sleep(2)

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            print("Error in custom_policy")

    def form_fill(self, idam) -> None:
        try:
            full_path = os.path.join(self.path, idam["file"])
            # print("this is the file  path   :   ", full_path)
            time.sleep(2)
            self.wait.until(
                EC.visibility_of_element_located(
                    (By.CSS_SELECTOR, "div.list-content a label")
                )
            )

            self.driver.execute_script(
                f'document.querySelector("div.list-content a label#{idam["select"]}").click()'
            )
            time.sleep(2)
            select_file_option = self.driver.find_element(
                By.CSS_SELECTOR, f"input#{idam['file_element']}"
            )
            select_file_option.send_keys(full_path)
            try:
                time.sleep(3)
                self.driver.switch_to.frame(idam["text_box"])

                self.driver.execute_script(
                    "document.querySelector('p').textContent = 'Automated Answer'"
                )
                self.driver.switch_to.default_content()
            except:
                print("error in adding text")

            # saving the uploaded file
            self.driver.execute_script(
                f'document.querySelector("button#{idam["save_button"]}").click()'
            )
            time.sleep(3)
        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            print("Error in idam 2")

    def check_form(self, form_data) -> None:
        """
        This function is used to verify the details that does it
        matches with details that we have given in the start
        step1: open bar one by one
        step2: check file name attached with it
        step3: check text that have added when creating nist
        """
        try:
            self.wait.until(
                EC.element_to_be_clickable(
                    (By.CSS_SELECTOR, "div.list-content a label")
                )
            )

            select = form_data["select"]
            time.sleep(3)

            # opens bar
            try:
                self.driver.execute_script(f'document.querySelector("#{select}").click()')
            except:
                pass
            
            try:
                child_no = form_data["child"]
                # check uploaded file
                file_name = self.driver.execute_script(
                    f'return document.querySelector("#uploaded_files_sec_{child_no - 1} > label > label").textContent'
                )
                print("file name is :   ", file_name)
                print("constants file name is : ", form_data["file"])
                if file_name == form_data["file"]:
                    print("File matched")
                else:
                    print("File doesn't matched that has attached with it")
            except:
                print("No file is present in question : ", form_data["child"])

            text_var = form_data["text_var"]
            try:
                # get text
                text_element = self.driver.find_element(By.CSS_SELECTOR, f"{text_var}")
                text = text_element.get_attribute("textContent")
                print("this is text     :   ", text)
                if text == "Automated Answer":
                    print("Text matched\n")
                else:
                    print("Text not matched\n")
            except:
                print("No text is present in question : ", form_data["child"])

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            print("Error in check form")

    def each_edit_section(self, count, topic):
        try:
            for i in range(count):
                self.edit_form(EDIT_ATTRIBUTES[f"form{i+1}"], topic)
        except:
            print("error in each_edit_pass")

    def edit_form(self, form, topic=None):
        """
        form parameter is a dictionary:
        This function is responsible of deleting file that are already present
        This function is responsible of adding file which is Automated Update
        This function is responsible of deleting text that are already present
        This function is responsible of adding text which is update.txt
        """
        try:
            # creating path where update.txt is present
            full_path = os.path.join(self.path, "update.txt")
            child_no = form["child"]

            # below line selects rows and also click on start button
            time.sleep(3)
            select = form["select"]
            save_btn = form["save_button"]
            text_box = form["text_box"]
            self.wait.until(EC.visibility_of_element_located((By.ID, f"{select}")))
            try:
                self.driver.find_element(By.ID, f"{select}").click()
            except:
                pass
            time.sleep(2)

            # this will delete file which is already present
            file_delete = self.delete_file_present(child_no)
            if file_delete:
                print("files deleted successfully that are already present")
            else:
                print("file not deleted successfully")
            time.sleep(1)
            
            # this will selects element where file needs to be attached
            select_file_option = self.driver.find_element(
                By.CSS_SELECTOR, f'input#{form["file_element"]}'
            )

            # this will attach update.txt file
            select_file_option.send_keys(full_path)
            time.sleep(1)

            # this will delete text
            text_removed = self.delete_text(form["text_box"])
            if text_removed:
                self.driver.switch_to.frame(form["text_box"])
                print("text deleted successfully")
            else:
                print("error in text delete")
            time.sleep(3)
            
            # self.wait.until(EC.visibility_of_element_located((By.ID, "uploaded_files_sec_1")))
            # switch to inside another html tag
            print("switch 1")
            
            # change the text
            self.driver.execute_script(
                "document.querySelector('p').textContent = 'Automated Update'"
            )
            # back to outside html tag
            self.driver.switch_to.default_content()
            print("switch 2")
            # saving the uploaded file
            try:
                self.driver.find_element(By.ID, f"{select}").click()
            except:
                pass
            time.sleep(2)
            # self.wait.until(EC.visibility_of_element_located((By.ID, f'{save_btn}')))
            self.driver.execute_script(
                f'document.querySelector("#{save_btn}").click()'
            )
            print("Succesfully updated form")
            print("\n")
            time.sleep(2)
        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            print("Error in edit form\n")

    def delete_text(self, text_frame):
        try:
            self.driver.switch_to.frame(text_frame)
            time.sleep(1)
            self.driver.execute_script("document.querySelector('p').textContent=' ' ")
            self.driver.switch_to.default_content()
            return True
        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            print("Error in delete text")
            return False

    def delete_file_present(self, child_no):
        """
        This function deletes already uploaded file and text. If file is present more than 
        one then loop is started which removes one by one
        """
        try:
            # get the length of files
            length_files = int(
                len(
                    self.driver.find_elements(
                        By.CSS_SELECTOR, f"#uploaded_files_sec_{child_no-1} label"
                    )
                )
                / 2
            )
            print("\n\nthis is the length of already attached files :   ")
            print(length_files)

            "enters in this condition when more than 1 files already uploaded previously"
            if length_files > 1:
                try:
                    for i in range(length_files):
                        self.wait.until(
                            EC.element_to_be_clickable(
                                (By.ID, f"uploaded_files_sec_{child_no-1}")
                            )
                        )
                        length_files = len(
                            self.driver.find_elements(
                                By.CSS_SELECTOR,
                                f"#uploaded_files_sec_{child_no-1} label",
                            )
                        )

                        if length_files == 0 or length_files == None:
                            print("all files are removed")
                            break
                        else:
                            # this will click on delete icon
                            self.driver.execute_script(
                                f'document.querySelector("#uploaded_files_sec_{child_no-1} > label:nth-child(1) > a").click()'
                            )
                            time.sleep(1)
                            # now pop up option to confirm
                            self.driver.execute_script(
                                'document.querySelector("body > div.sweet-alert.showSweetAlert.visible > div.sa-button-container > div > button").click()'
                            )
                            time.sleep(3)

                except Exception as e:
                    print(
                        type(e).__name__,  # TypeError
                        e.__traceback__.tb_lineno,  # 2
                        traceback.format_exc(),
                    )
                    print("error in deleting multiple file")
            elif length_files == 1:
                # this will click on delete icon
                self.driver.execute_script(
                    f'document.querySelector("#uploaded_files_sec_{child_no-1} > label:nth-child(1) > a").click()'
                )
                time.sleep(1)
                # now pop up option to confirm
                self.driver.execute_script(
                    'document.querySelector("body > div.sweet-alert.showSweetAlert.visible > div.sa-button-container > div > button").click()'
                )
                time.sleep(3)
                print("step 3")
            else:
                print("No file attached already")
            length_files = len(
                self.driver.find_elements(
                    By.CSS_SELECTOR, f"#uploaded_files_sec_{child_no-1} label"
                )
            )
            # print("\nthis is the length of attached files :   ", length_files)
            if length_files == 0:
                return True

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            print("error in delete_file_present")
            return False

    def go_to_dashboard(self):
        try:
            self.driver.execute_script(
                "document.querySelectorAll('ul.action-drop li a')[3].click()"
            )
            print("\n", "*" * 5, "Entered Dashboard Page", "*" * 5)
        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            print("Error in action perform function")

    def dashboard(self):
        try:
            self.task_assignment()
            # match URL
            time.sleep(5)
            length_clouds = self.driver.execute_script(
                "return document.querySelectorAll('#assetsList div.row.clearfix').length"
            )

            if length_clouds != 0:
                # first check number of aws and azure
                clouds = self.driver.find_elements(
                    By.CSS_SELECTOR, "#assetsList div.row.clearfix"
                )
                length_clouds = len(clouds)
                print("\nthis is the length of clouds :   ", length_clouds)
                if length_clouds == 0 or length_clouds == None:
                    print("\nThere is no Automated Report present\n")
                else:
                    for i in range(length_clouds):
                        self.wait.until(
                            EC.visibility_of_element_located(
                                (By.ID, f"accordian_{i}_a")
                            )
                        )

                        # this will click on each cloud
                        self.driver.execute_script(
                            f'document.querySelector("#accordian_{i}_a").click()'
                        )
                        time.sleep(1)

                        # this will count number of rows inside aws
                        row = self.driver.find_elements(
                            By.CSS_SELECTOR, f"#innerCard{i} div.box-holder"
                        )
                        row_length = len(row)
                        print("\nthis is the length   :   ", row_length)

                        cloud_name = self.driver.execute_script(
                            f'return document.querySelector("#label{i}").textContent'
                        )
                        cloud_name = cloud_name.lower()
                        print("\n\n this is the cloud name :    ", cloud_name)
                        for j in range(row_length):
                            # for getting text
                            scan_name = self.wait.until(
                                EC.visibility_of_element_located(
                                    (
                                        By.CSS_SELECTOR,
                                        f"#innerCard{i} > div:nth-child({j+1}) > div:nth-child(1) > div:nth-child(1) > p",
                                    )
                                )
                            ).text
                            print("\nthis is the scan name :  ", scan_name, "\n")

                            "If within_process is not none its mean that this scan is under process"
                            within_process = self.driver.execute_script(
                                f'return document.querySelector("#show_report_{cloud_name}_{j} > button").getAttribute("title")'
                            )
                            if within_process == None:
                                time.sleep(2)
                                # for clicking details on scan
                                self.driver.execute_script(
                                    f'document.querySelector("#show_report_{cloud_name}_{j} > button").click()'
                                )

                                # this will check all the given numbers of pass, failed, error and manual
                                total_results = self.matching_number_and_elements()
                                self.export_report(total_results)
                                self.driver.back()
                            else:
                                print("this scan is under process : ", scan_name)
            else:
                print("no cloud record found of this dashboard")
        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            print("Error in dashboard")

    def check_records(self, number_col: int = None):
        """
        This is a generic function that is used to perform
        1) gets records list and count the list
        2) Page records increased when list is greater than 10
        3) Match below table mentioned total records with gets total records by automation
        4) If it doesn't match then generate a print
        """
        try:
            # the line below table which tells total_records
            total_records = self.driver.execute_script(
                "return document.querySelector('div.dataTables_info').querySelector('b').textContent"
            )
            total_records = int(total_records)
            print("overall total records    :   ", total_records)

            # This function checks total records are they greater than 10
            if total_records > 10:
                "Increase the size of records"
                print("total records of user groups are greater than 10")
                ele_page_records = "time_filter"
                count = 0
                self.page_records_to_100(ele_page_records)

                # Getting all records
                records_before_create = self.driver.execute_script(
                    "return document.querySelector('tbody').querySelectorAll('input')"
                )
                total_records_first_page = len(records_before_create)
                count = 100
                time.sleep(3)
                try:
                    while True:
                        time.sleep(3)
                        if total_records > count:
                            self.driver.execute_script(
                                'document.querySelector("#create_td_next > a").click()'
                            )
                            time.sleep(3)
                            records_before_create = self.driver.execute_script(
                                "return document.querySelector('tbody').querySelectorAll('input')"
                            )

                            total_records_first_page += len(records_before_create)
                            count += 100
                        elif total_records <= count:
                            break
                except:
                    print("error in changing files")

            else:
                # Getting all records
                records_before_create = self.driver.execute_script(
                    "return document.querySelector('tbody').querySelectorAll('input')"
                )
                total_records_first_page = len(records_before_create)

            if (total_records_first_page) != total_records:
                print(
                    "this is the number of rows present inside table  :   ",
                    total_records_first_page,
                )
                print("Table below line which tells total record doesn't match")

            return total_records_first_page, total_records

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )

    def go_to_dashboard(self):
        """
        This function first go to the dashboard
        """
        try:
            self.wait.until(
                EC.visibility_of_element_located((By.CSS_SELECTOR, "#cratbody tr td"))
            )
            try:
                # clicks the action button when single record found on search
                self.driver.execute_script(
                    'document.querySelector("#cratbody > tr > td:nth-child(7) > ul > li > a > button").click()'
                )
            except:
                # clicks the action button when multiple records found on search
                self.driver.execute_script(
                    'document.querySelector("#cratbody > tr:nth-child(1) > td:nth-child(7) > ul > li > a > button").click()'
                )

            self.driver.execute_script(
                "document.querySelector('body > ul > li:nth-child(2) > a').click()"
            )
            time.sleep(1)
            if self.driver.current_url == NIST_DATA_DASHBOARD_URL:
                self.dashboard()

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            print("Error in function go_to_dashboard")

    def go_to_data_partners(self):
        """
        this will go to data partners page by clicking option inside an action button
        """
        try:
            self.driver.execute_script(
                "document.querySelectorAll('ul.action-drop li a')[2].click()"
            )
            time.sleep(3)
            if self.driver.current_url == NIST_DATA_PARTNERS_PAGE_URL:
                print(10 * "*", "entered data partners", 10 * "*")
                # this check_records function counts all number of rows of table
                # total_records_by_rows, total_records = self.check_records()
                # print("\ntotal records before create data partner   :\t", total_records)
                
                # this will create a data partner
                time.sleep(5)
                self.create_data_partner()
                time.sleep(5)
                
                self.driver.back()
                time.sleep(4)

                # total_records_after_create, _ = self.check_records()
                # if total_records_after_create > total_records_by_rows:
                #     print("new record is added in table successfully")
                # elif total_records_after_create == total_records_by_rows:
                #     print("new record is not added")
                # elif total_records_after_create < total_records_by_rows:
                #     print("This count is less than previous one")
                # else:
                #     print("other problem occured")
            else:
                print("Page is not matched ")
        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            print("Error in function go_to_data_partners")

    def create_data_partner(self):
        """
        This will create new data partner. It fills following items
        Data Partner
        Policy
        Terms of Use
        """
        try:
            print("entered create data partner")
            
            # this will open create data partner page
            self.driver.execute_script(
                'document.querySelector("#m_top > a > img").click()'
            )
            time.sleep(3)
            self.driver.execute_script(
                f"document.querySelector(\"#new_partner\").value='{self.name.lower()}.com' "
            )
            time.sleep(5)
            self.driver.execute_script(
                f'document.querySelector("#policy").value="http://{self.name.lower()}.com"'
            )
            time.sleep(5)
            self.driver.execute_script(
                f'document.querySelector("#terms_url").value="http://{self.name.lower()}.com"'
            )
            time.sleep(1)
            # this will click on save button
            self.driver.execute_script('document.querySelector("#submit-form").click()')
            time.sleep(4)
            
            # check record is created or not
            self.driver.find_element(By.CSS_SELECTOR, "#partner_search").send_keys(self.name.lower())
            time.sleep(3)
            self.driver.find_element(By.CSS_SELECTOR, "#submit-form11").click()
            time.sleep(3)
            policy_name = self.driver.execute_script('return document.querySelector("#create_td > tbody > tr > td:nth-child(1)").textContent')
            created_policy = self.name.lower() +".com"
            print("this is created policy   ", created_policy)
            print("this is policy name  :   ", policy_name)
            if policy_name == (self.name.lower() +".com"):
                print("New policy created successfully")
            else:
                print("Policy is not created") 
        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            print("error in creating data partner")

    def matching_number_and_elements(self):
        """
        this will match passed number that are already given and match with the number of elements that are already present
        """
        try:
            time.sleep(2)
            if self.driver.current_url == NIST_MATCH_AUTOMATED_REPORT_PAGE_URL:
                time.sleep(1)

                passed = int(
                    self.wait.until(
                        EC.visibility_of_element_located((By.ID, "ok_count"))
                    ).text
                )

                # Retrieve the text content
                passed_elements = len(
                    self.driver.find_elements(By.CSS_SELECTOR, ".d-flex.ok")
                )
                if passed == passed_elements:
                    print("passed length matched")
                else:
                    print("passed length not matched")

                # getting number that are failed
                failed = int(
                    self.wait.until(
                        EC.visibility_of_element_located((By.ID, "alarm_count"))
                    ).text
                )
                failed_elements = len(
                    self.driver.find_elements(By.CSS_SELECTOR, ".d-flex.alarm")
                )

                if failed == failed_elements:
                    print("failed length matched")
                else:
                    print("failed length not matched")

                # getting error number that are already written
                error = int(
                    self.wait.until(
                        EC.visibility_of_element_located((By.ID, "error_count"))
                    ).text
                )

                # this will get all elements where elements are error
                error_elements = len(
                    self.driver.find_elements(By.CSS_SELECTOR, ".d-flex.error")
                )

                if error == error_elements:
                    print("error length matched")
                else:
                    print("error length not matched")

                #  getting number that are manual
                manual = int(
                    self.wait.until(
                        EC.visibility_of_element_located((By.ID, "manual_count"))
                    ).text
                )

                #  getting number that are manual
                manual_elements = len(
                    self.driver.find_elements(By.CSS_SELECTOR, ".d-flex.manual")
                )
                if manual == manual_elements:
                    print("length matched")
                else:
                    print("manual length not matched")
                print(
                    "passed number  :   ",
                    passed,
                    "\tfailed number :",
                    failed,
                    "\terror number :",
                    error,
                    "\tmanual number :",
                    manual,
                )
                # total results are
                total_results = passed + failed + error + manual
                return total_results
            else:
                print("URL not matched of AUTOMATED REPORT PAGE URL")
        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            print("Error in matching number and elements")

    def export_report(self, total_results):
        """
        *GENERIC FUNCTION*
        This will download the report and we have to follow these steps
        1) Download report
        2) Read File pending
        3) Match with total numbers pending
        """
        try:
            # this clicks the scanned result +
            self.driver.execute_script(
                'document.querySelector("#controls_card > div.row.box-holder > div:nth-child(5) > div:nth-child(1) > div > button").click()'
            )

            time.sleep(1)
            # this selects one item from the list
            self.driver.execute_script(
                "document.querySelector('ul.dropdown-menu.inner li[data-original-index=\"0\"] a').click()"
            )

            time.sleep(1)
            # this selects export format option
            self.driver.execute_script(
                'document.querySelector("#controls_card > div.row.box-holder > div:nth-child(5) > div:nth-child(2) > div > button").click()'
            )

            time.sleep(1)
            # this selects the CSV format
            self.driver.execute_script(
                'document.querySelector("#controls_card > div.row.box-holder > div:nth-child(5) > div:nth-child(2) > div > div > ul > li:nth-child(1) > a").click()'
            )

            # this will export the file and save in the downloads
            self.driver.execute_script(
                'document.querySelector("#controls_card > div.row.box-holder > div:nth-child(5) > div:nth-child(3) > button").click()'
            )
            time.sleep(5)

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            print("\n\n Error in export report")

    def task_assignment(self):
        try:
            self.driver.execute_script(
                'document.querySelector("#most_phished_body > li:nth-child(3) > div > div.col-auto > div > a > #save_change").click()'
            )
            time.sleep(4)
            # check_table_value = self.wait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, '#create_td > tbody > tr.odd'))).text
            print("\n", "*" * 5, "Inside Dashboard Task Assignment", "*" * 5)
            check_table_value = self.driver.execute_script(
                'return document.querySelector("#create_td > tbody > tr.odd").textContent'
            )

            if check_table_value == "No data available in table":
                before_rows_length = 0
                print("No Task Assignment present")
                print("\nthis is the rows length  ", before_rows_length)
            else:
                time.sleep(2)
                before_rows_length = len(
                    self.driver.find_elements(
                        By.CSS_SELECTOR, "#create_td > tbody > tr "
                    )
                )
                print("\nthis is the rows length  ", before_rows_length)
            time.sleep(1)
            response = requests.get("https://api.namefake.com/")
            if response.status_code == 200:
                # Extract the name from the response
                data = response.json()
                name = data["name"]
                resource_name = "Automate" + name.replace(" ", "")
                resource_name = resource_name.replace(".", "")
                resource_name = resource_name.replace(",", "")
                resource_name = resource_name.replace("-", "")

            self.task_assignment_form(resource_name)

            # this will get length of rows of table after record is created
            time.sleep(3)
            after_rows_length = len(
                self.driver.find_elements(By.CSS_SELECTOR, "#create_td tbody tr")
            )
            print("this is the after rows length ", after_rows_length)

            if before_rows_length < after_rows_length:
                print("new task assignment is created")

                # filter the table
                time.sleep(2)
                try:
                    filter = self.driver.find_element(
                        By.CSS_SELECTOR, "#create_td_filter > label > input"
                    )
                    filter.send_keys(resource_name)
                    if (
                        len(
                            self.driver.find_elements(
                                By.CSS_SELECTOR, "#create_td > tbody > tr "
                            )
                        )
                        == 1
                    ):
                        print("filter inside Task Assignment is working properly")
                except:
                    print("filter option is not available")

            else:
                print("new task assignment is not created")
            self.driver.back()

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            print("error in task assignment")

    def task_assignment_form(self, resource_name):
        """
        This function is used to create task assignment form in which
        gets email from .env file
        start and end date is get from python
        """
        try:
            # Resource Name
            self.driver.find_element(By.ID, "resource_name").send_keys(resource_name)

            # dropdown option
            self.driver.find_element(By.ID, "control_val").click()
            time.sleep(1)
            self.driver.execute_script(
                'document.querySelector("span.comboTreeItemTitle.selectable > input[type=checkbox]").click()'
            )

            today = datetime.now().date()
            start_date = today.strftime("%m/%d/%Y")
            # Start date
            self.driver.find_element(By.ID, "comp_date").send_keys(start_date)

            end_date = date.today() + timedelta(days=2)
            end_date = end_date.strftime("%m/%d/%Y")

            # End date
            self.driver.find_element(By.ID, "comp_date2").send_keys(end_date)

            # Email
            self.driver.find_element(By.ID, "email").send_keys(os.getenv("EMAIL"))
            time.sleep(4)
            # save button click
            self.driver.find_element(By.ID, "submit-form").click()
        except:
            print("\n", "*" * 5, "Problem in Task Assignment Form")

    def page_records_to_100(self, element):
        """
        This function selects 100 page records it is called only when page records are greater than 10
        """
        try:
            self.driver.execute_script(
                "document.querySelector('button[data-id=\"{}\"]').click()".format(
                    element
                )
            )
            time.sleep(4)
            selecting_page_records = self.driver.find_element(
                By.CSS_SELECTOR,
                '#filt_result ul.dropdown-menu.inner li[data-original-index ="3"] a',
            )
            # selecting_page_records = self.driver.execute_script('document.querySelectorAll(\'ul.dropdown-menu.inner li[data-original-index ="3"] a\')[0].click()')

            selecting_page_records.click()
        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            print("Error in selecting 100 records")

    def search_by_audit(self, name=None):
        """
        This function can do search functionality and we can pass a parameters of name we need to search
        If name is not passed in parameters it will defaulty search that name which is present inside
        self.name
        """
        try:
            if name == None:
                name = self.name
            time.sleep(1)
            self.wait.until(EC.visibility_of_element_located((By.ID, "submit-form")))
            search = self.driver.find_element(By.CSS_SELECTOR, "input#new_partner")
            search.clear()
            time.sleep(2)
            search.send_keys(name)
            # search.send_keys("DrTammyBlankenship")
            
            time.sleep(1)
            try:
                self.driver.find_element(By.CSS_SELECTOR, "input#submit-form").click()
            except:
                pass
            time.sleep(2)
        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            print("Error in search_by_audit")

    def check_filter(self):
        """
        this checks the filter that is in audit inventory
        """
        try:
            print("\nEntered Filter")
            time.sleep(2)
            # this will pick first name
            name = self.driver.execute_script('return document.querySelector("tbody#cratbody td").textContent')
            time.sleep(2)
            
            filter_element = self.driver.execute_script(
                'return document.querySelector("#create_td_filter > label > input")'
            )
            filter_element.send_keys(name)
            time.sleep(1)
            
            # this will check the rows after applying filter
            length_records = self.driver.execute_script(
                'return document.querySelectorAll("#cratbody > tr[role=\\"row\\"]").length'
            )
            if length_records >= 1:
                print("filter is working properly")
            else:
                print("filter records is zero")
            filter_element.clear()
            # this will press backspace key
            filter_element.send_keys(Keys.BACKSPACE)
            time.sleep(1)
        except:
            filter_element.clear()
            filter_element.send_keys(Keys.BACKSPACE)
            time.sleep(1)
            print("\nfilter is not working properly")

    def remove_created_nist_audit(self):
        try:
            print("\n", "*" * 5, "Entered Remove Audit", "*" * 5)

            # selects delete option
            self.driver.execute_script(
                "document.querySelectorAll('ul.action-drop li a')[4].click()"
            )
            time.sleep(1)
            self.driver.find_element(By.ID, "delete_reason").send_keys(
                "Automation testing Purpose"
            )
            # self.driver.find_element(By.ID, "delete_reason").send_keys("Automation testing Purpose")
            self.driver.find_element(By.ID, "save_changes122").click()
            time.sleep(1)
            self.driver.find_element(By.CLASS_NAME, "confirm").click()
            print(" Record deleted Successfully")

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            print("Error remove created nist audit")

    def giving_reason_edit(self) -> None:
        """
        This function will be called when edit option is selected and it updates the status
        And also give reason
        """
        try:
            time.sleep(2)
            # for clicking status after clicking edit
            self.driver.execute_script(
                'document.querySelector("#edit_modal_body > div:nth-child(4) > div > button > span.filter-option.pull-left").click()'
            )

            time.sleep(1)

            # this will selects status inprogress
            self.driver.execute_script(
                'document.querySelector("#edit_modal_body > div:nth-child(4) > div > div > ul > li:nth-child(2) > a").click()'
            )

            # this will sends reason
            # entering reason
            self.driver.execute_script(
                'document.querySelector("#last_reason").value = "Automate Edit" '
            )
            time.sleep(1)

            # activate the disabled save button
            self.driver.execute_script(
                'document.querySelector("#save_changes12").disabled=false;'
            )

            # clicks on save after entering reason
            self.driver.execute_script(
                'document.querySelector("#save_changes12").click()'
            )
        except:
            print("Error giving reason for Edit")
