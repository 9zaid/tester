from constants_cytex import *
import time
from selenium.webdriver.common.by import By
import traceback
from selenium.webdriver.support import expected_conditions as EC
import os
from common_functionalities import CommonUsed
from RegulatoryCompliances.regulatory_common import Regulatory_Compliance_Common
from user_input import *


class Audify:
    def __init__(self, driver=None) -> None:
        if driver is not None:
            self.driver = driver
            self.common = CommonUsed(driver)
        else:
            self.driver = None
            self.common = CommonUsed()
            # self.reg_common = Regulatory_Compliance_Common(self.driver)

        self.path = os.getcwd()
        self.path_docs = os.path.join(self.path, "docs")
        self.path = os.path.join(self.path, "txt")
        self.name = AUDIT_NAME
        # self.name = "AmandaSmith"
        self.name = str(self.name).replace(" ", "")
        self.name = str(self.name).replace(",", "")
        self.name = str(self.name).replace(".", "")
        self.name = str(self.name).replace("-", "")
        self.name = str(self.name).replace("_", "")


    def main(self):
        """
        This function is responsible for performing all tasks because in this we call the
        functionality that we need to automate if its function is already prepared and
        functioning properly.
        """
        try:
            print("entered Audify main")
            self.lock_file_path = "lockfile.lock"
            status = self.check_status()
            self.reg_comp_id = "compli"
            self.nist_page_id = "audify"
            if status != "Already Created":
                self.common.start()
                self.driver = self.common.driver
                print("entering to wait")
                self.common.wait.until(
                    EC.element_to_be_clickable((By.NAME, "text")))
                # This function login user when passed credentials
                self.common.login_page(login_user_list[0])

            # This will redirect to regulatory page
            time.sleep(3)
            self.common.user_mgmt_path_sub_modules(
                self.reg_comp_id, self.nist_page_id, "regulatory_compliance", "audify"
            )

            self.reg_common = Regulatory_Compliance_Common(
                self.common.wait, self.driver, self.path, self.path_docs, self.name
            )
            
            time.sleep(1)
            # self.wait.until(EC.element_to_be_clickable((By.ID, sub_component)))
            # self.driver.execute_script(
            #             f'document.querySelectorAll("#{sub_component}")[1].click()')
            self.driver.execute_script('document.querySelector("#customControls > span").click()')
            time.sleep(2)
            
            self.audify_page()

            return self.driver

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
     
    def audify_page(self):
        """
        This function have all main functionalities of nist_sp page
        """
        try:
            time.sleep(2)
            print("entered  Audify page")

            if self.driver.current_url == AUDIFY_PAGE_URL:
                # self.main_control()
                
                # this function has all functionalities inside action button inside nist_sp page
                self.action_perform()

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            print("Error in audify page function")

    def main_control(self):
        """
        This function is used to add controls and how many we want to add it all depends on this function
        """
        try:
            print("Inside main control")
            for i in range(1):
                # this will click on plus sign
                self.driver.execute_script('document.querySelector("#add_new_control_btn > span").click()')
                time.sleep(4)
                self.add_control()
            
        except:
            print("error in main control Audify")
    
    
    def add_control(self):
        """
        This function is called when a audit has to fill a form before creating new audit
        """
        try:
            print("entered add controls inside Audify")
            if self.driver.current_url == AUDIFY_ADD_CONTROL_PAGE_URL:
                
                self.driver.find_element(
                    By.CSS_SELECTOR, "#controlDescription"
                ).send_keys(self.name)
                
                if audify_control["framework"]:
                    # select framework
                    self.driver.execute_script('document.querySelector("#addCustomControlForm > div > div:nth-child(1) > div > div:nth-child(2) > div > div > button").click()')
                    # selecting option which is IramFramework
                    self.driver.execute_script('document.querySelector("#addCustomControlForm > div > div:nth-child(1) > div > div:nth-child(2) > div > div > div > ul > li.selected > a").click()')
                
                if audify_control["group"]:
                    # select group
                    self.driver.execute_script('document.querySelector("#addCustomControlForm > div > div:nth-child(2) > div > div:nth-child(1) > div > div > button > span.filter-option.pull-left").click()')
                    # selecting group option
                    self.driver.execute_script('document.querySelector("#addCustomControlForm > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div > ul > li:nth-child(2) > a").click()')
                
                if audify_control["category"]:
                    # select category
                    self.driver.execute_script('document.querySelector("#addCustomControlForm > div > div:nth-child(2) > div > div:nth-child(1) > div > div > button > span.filter-option.pull-left").click()')
                    # selecting category option
                    self.driver.execute_script('document.querySelector("#defaultBadge > div > div > ul > li:nth-child(2) > a").click()')
                
                # # select all reg compliances
                # self.driver.execute_script('document.querySelector("#selectAll").click()')
                # time.sleep(1)
                
                try:
                    time.sleep(3)
                    # Decription
                    self.driver.switch_to.frame("pofDescription_0_ifr")
                    self.driver.execute_script(
                        "document.querySelector('p').textContent = 'Automated Description'"
                    )
                    # back to normal frame
                    self.driver.switch_to.default_content()
                    
                    time.sleep(1)
                    # this is the guidance
                    self.driver.switch_to.frame("hintDescription_0_ifr")
                    self.driver.execute_script(
                        "document.querySelector('p').textContent = 'Automated Guidanace'"
                    )
                    # back to normal frame
                    self.driver.switch_to.default_content()
                    time.sleep(1)
                    
                except:
                    print("error in filling the description and guidance")
                
                
                # this will click submit button
                self.driver.execute_script('document.querySelector("#submitBtn").click()')
                time.sleep(2)
            else:
                print("Url is not matched")
        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )

    
    def action_perform(self):
        try:
            self.reg_common.search_by_audit("KarenLevy")
            self.go_to_edit()
            self.driver.back()
            time.sleep(3)

            # self.reg_common.search_by_audit()
            # self.reg_common.remove_created_nist_audit()
            # time.sleep(3)
        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            self.driver.back()
            print("error in action perform")
    
    
    def go_to_edit(self) -> None:
        try:
            time.sleep(4)
            print(10 * "*", "ENTERED EDIT AUDIFY PAGE", 10 * "*")
            try:
                # clicks the action button when single record found on search
                self.driver.execute_script(
                    'document.querySelector("#action_btn > li > a > button").click()'
                )
                time.sleep(1)
                self.driver.execute_script(
                    'document.querySelector("body > ul > li:nth-child(2) > a").click()'
                )
            except:
                print("Error in clicking action button")
                
            time.sleep(2)
            
            # this function will give reasons
            self.giving_reason_before_edit()
            time.sleep(4)

            if self.driver.current_url == AUDIFY_EDIT_PAGE_URL:
                time.sleep(1)
                print("Entered edit portion after matching EDIT URL")
                self.updating_audify()

                print("\n", "*" * 5, "All Answers are Updated", "*" * 5)
            else:
                print("URL not matched")

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            self.driver.back()
            
    def giving_reason_before_edit(self) -> None:
        """
        This function will be called when edit option is selected and it will give reason of edit
        """
        try:
            time.sleep(2)
            
            # entering reason
            self.driver.execute_script(
                'document.querySelector("#edit_reason").value = "Automate Edit" '
            )
            time.sleep(1)

            # activate the disabled save button
            self.driver.execute_script(
                'document.querySelector("#save_changes").disabled=false;'
            )

            # clicks on save after entering reason
            self.driver.execute_script(
                'document.querySelector("#save_changes").click()'
            )
        except:
            print("error in edit giving reason for audify")
            
            
    def updating_audify(self):
        try:
            try:
                time.sleep(6)
                # self.driver.execute_script("document.querySelector('body[data-id=\"pofDescription_1\"]').textContent='Updated Automated Description'")
                print("111111111111111111111111")
                self.common.wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, "#mceu_27")))
                # Decription
                # self.driver.switch_to.frame("pofDescription_0_ifr")
                # self.driver.switch_to.frame(self.driver.find_element(By.ID, "pofDescription_0_ifr"))
                self.driver.switch_to.frame(self.driver.execute_script('document.querySelector("#pofDescription_0_ifr")'))
                print("2222222222222222222222222222")

                # time.sleep(6)
                # self.driver.execute_script(
                #     "document.querySelector('p').textContent = ''"
                # )
                # self.common.wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, "p")))
                self.common.wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, "#mceu_27")))
                time.sleep(10)
                # Find all div elements inside the iframe
                # div_elements = self.driver.find_elements(By.TAG_NAME, "p")
                div_elements = self.driver.execute_script("return document.querySelector('p').textContent")

                # print("333333333333333333333333")
                print(div_elements)
                # print("texttttttttttttttttttttttt")
                # print(div_elements.text)
                
                # Print the text of each div element
                # for div in div_elements:
                #     print(div.text)
                print("4444444444444444444444")
                
                self.driver.execute_script(
                    "document.querySelector('p').textContent = 'Updated Automated Description'"
                )
                print("555555555555555555555555")
                
                # back to normal frame
                self.driver.switch_to.default_content()
                
                # time.sleep(4)
                # # this is the guidance
                # self.driver.switch_to.frame("hintDescription_0_ifr")
                # time.sleep(2)
                # self.driver.execute_script(
                #     "document.querySelector('p').textContent = ''"
                # )
                # time.sleep(1)
                # self.driver.execute_script(
                #     "document.querySelector('p').textContent = 'Updated Automated Guidanace'"
                # )
                # # back to normal frame
                # self.driver.switch_to.default_content()
                time.sleep(1)
                    
            except Exception as e:
                print(
                    type(e).__name__,  # TypeError
                    e.__traceback__.tb_lineno,  # 2
                    traceback.format_exc(),
                )
                print("error in filling the description and guidance")
                
            # this will click submit button
            self.driver.execute_script('document.querySelector("#submitBtn").click()')
            time.sleep(2)
                
        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            print("Error in updating Audify")

    # def search_by_audit(self, name=None):
    #     """
    #     This function can do search functionality and we can pass a parameters of name we need to search
    #     If name is not passed in parameters it will defaulty search that name which is present inside
    #     self.name
    #     """
    #     try:
    #         if name == None:
    #             name = self.name
    #         time.sleep(1)
    #         self.wait.until(EC.visibility_of_element_located((By.ID, "new_partner")))
    #         search = self.driver.find_element(By.CSS_SELECTOR, "input#new_partner")
    #         search.clear()
    #         time.sleep(2)
    #         search.send_keys(name)
    #         # search.send_keys("DrTammyBlankenship")
            
    #         time.sleep(1)
    #         try:
    #             self.driver.find_element(By.CSS_SELECTOR, "input#submit-form").click()
    #         except:
    #             pass
    #         time.sleep(2)
    #     except Exception as e:
    #         print(
    #             type(e).__name__,  # TypeError
    #             e.__traceback__.tb_lineno,  # 2
    #             traceback.format_exc(),
    #         )
    #         print("Error in search_by_audit")

    def each_edit(self, index_control):
        try:
            time.sleep(2)
            
        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            self.driver.back()
    
    def check_status(self):
        "This function checks that lock file is present or not which means browser is running"
        if os.path.exists(self.lock_file_path):
            return "Already Created"
        else:
            # Create lock file
            open(self.lock_file_path, "w").close()
            return "Not Created"