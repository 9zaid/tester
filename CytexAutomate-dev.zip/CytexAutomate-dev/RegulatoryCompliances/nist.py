from constants_cytex import *
import time
from selenium.webdriver.common.by import By
import traceback
from selenium.webdriver.support import expected_conditions as EC
import os
from common_functionalities import CommonUsed
import random
from RegulatoryCompliances.regulatory_common import Regulatory_Compliance_Common


class NIST:
    def __init__(self, driver=None) -> None:
        if driver is not None:
            self.driver = driver
            self.common = CommonUsed(driver)
        else:
            self.driver = None
            self.common = CommonUsed()
            # self.reg_common = Regulatory_Compliance_Common(self.driver)

        self.path = os.getcwd()
        self.path_docs = os.path.join(self.path, "docs")
        self.path = os.path.join(self.path, "txt")
        self.name = AUDIT_NAME
        # self.name = "AmandaSmith"
        self.name = str(self.name).replace(" ", "")
        self.name = str(self.name).replace(",", "")
        self.name = str(self.name).replace(".", "")
        self.name = str(self.name).replace("-", "")
        self.name = str(self.name).replace("_", "")

    def main(self):
        """
        This function is responsible for performing all tasks because in this we call the
        functionality that we need to automate if its function is already prepared and
        functioning properly.
        """
        try:
            self.lock_file_path = "lockfile.lock"

            status = self.check_status()
            ELEMENT_REGULATORY_COMPLIANCE = "ul li#regulatory_main a"
            ELEMENT_NIST = "ul.ml-menu.compliUl li a#nist"
            self.reg_comp_id = "compli"
            self.nist_page_id = "nist"
            if status != "Already Created":
                self.common.start()
                self.driver = self.common.driver
                print("entering to wait")
                self.common.wait.until(
                    EC.element_to_be_clickable((By.NAME, "text")))
                # This function login user when passed credentials
                self.common.login_page(login_user_list[0])

            # This will redirect to regulatory page
            time.sleep(3)
            self.common.user_mgmt_path_sub_modules(
                self.reg_comp_id, self.nist_page_id, "regulatory_compliance", "nist"
            )

            self.reg_common = Regulatory_Compliance_Common(
                self.common.wait, self.driver, self.path, self.path_docs, self.name
            )
            time.sleep(1)
            self.nist_page()

            return self.driver

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )

    def nist_page(self):
        try:
            time.sleep(2)

            if self.driver.current_url == NIST_PAGE_URL:
                self.create_nist_audit()
                self.driver.back()
                self.driver.back()
                self.action_perform()

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            print("Error in NIST page function")

    def start_audit(self):
        try:
            if self.driver.current_url == NIST_START_AUDIT_PAGE_URL:
                print("this is audit name : ", self.name)
                address = AUDIT_ADDRESS
                self.driver.find_element(
                    By.CSS_SELECTOR, "div input#auditName"
                ).send_keys(self.name)
                self.driver.find_element(
                    By.CSS_SELECTOR, "div input#company_name"
                ).send_keys("MSFT")
                self.driver.find_element(
                    By.CSS_SELECTOR, "div input#company_ddress"
                ).send_keys(address)
                self.driver.find_element(
                    By.CSS_SELECTOR, "button#submit_audit_btn"
                ).click()
                time.sleep(2)
        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )

    def create_nist_audit(self):
        try:
            self.driver.find_element(
                By.CSS_SELECTOR, "div#m_top a img").click()
            time.sleep(2)
            self.start_audit()
            if self.driver.current_url == NIST_CREATE_AUDIT_PAGE_URL:
                print("\n", "*" * 10, "Entered Create NIST Page", "*" * 10)

                time.sleep(1)
                self.identify()
                self.protect()
                self.detect()
                self.recover()
                self.respond()
                print("All Questions are answered\n")

            else:
                print("Url not matched")

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            print("Error in creating nist audit")

    def identify(self):
        """
        This function solves all questions sections of indentify only by selecting each portion one by one
        """
        try:
            time.sleep(2)
            self.selecting_identify()
            self.common.wait.until(
                EC.visibility_of_element_located(
                    (By.CSS_SELECTOR, "#create_td_1 "))
            )

            # this will count number of parts inside identify
            no_of_parts = self.driver.execute_script(
                'return document.querySelectorAll("#create_td_1 > tbody > tr > td > button ").length'
            )
            print("this is the number of parts", no_of_parts)

            for i in range(no_of_parts):
                time.sleep(2)
                self.selecting_identify()
                time.sleep(1)

                # this will get the part name that is inside identify
                part_name = self.driver.execute_script(
                    f'return document.querySelector("#create_td_1 > tbody > tr:nth-child({i+1}) > td.sorting_1 > span").textContent'
                )

                # this will click a part to give answer
                self.driver.execute_script(
                    f'document.querySelector("#create_td_1 tr[role=\\"row\\"]:nth-child({i+1}) button").click()'
                )
                time.sleep(3)

                # this will attach pollicy document
                self.reg_common.attach_policy_doc()
                print("\nthis is the part name    :\t", part_name)
                time.sleep(2)

                # number of questions inside each part
                number_of_questions = self.driver.execute_script(
                    'return document.querySelectorAll(".list-content").length'
                )
                if number_of_questions > 8:
                    print("number of questions greater than 8")
                    number_of_questions = 8
                for j in range(number_of_questions):
                    val = f"idam{j + 1}"

                    # this will fill the text and attach file as well
                    self.reg_common.form_fill(IDAM_VARIABLES[val])
                self.driver.back()
            print("\n", "*" * 5, "Successfully answered Indentify", "*" * 5)

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            self.driver.back()
            print("Error in Identify")

    def view_identify(self):
        try:
            time.sleep(2)
            self.selecting_identify()
            self.common.wait.until(
                EC.visibility_of_element_located(
                    (By.CSS_SELECTOR, "#create_td_1 "))
            )

            # this will count number of parts inside identify
            no_of_parts = self.driver.execute_script(
                'return document.querySelectorAll("#create_td_1 .sorting_1").length'
            )
            print("this is no of parts :    ", no_of_parts)
            if no_of_parts > 0:
                for i in range(no_of_parts):
                    time.sleep(1)

                    # get part name that record is going to match
                    part_name = self.driver.execute_script(
                        f'return document.querySelector("#create_td_1 > tbody > tr:nth-child({i+1}) > td.sorting_1 > span").textContent'
                    )
                    time.sleep(2)

                    # this will click on view button
                    self.driver.execute_script(
                        f'document.querySelector("#create_td_1 > tbody > tr:nth-child({i+1}) #submit-form1").click()'
                    )
                    print("\nthis is the part name    :\t", part_name)
                    time.sleep(2)

                    # this will count total number of questions
                    number_of_questions = self.driver.execute_script(
                        'return document.querySelectorAll(".list-content").length'
                    )

                    if number_of_questions > 8:
                        print("number of questions greater than 8")
                        number_of_questions = 8

                    for j in range(number_of_questions):
                        val = f"form{j + 1}"

                        # this function will check all the details entered while creating audit
                        self.reg_common.check_form(CHECK_ATTRIBUTES[val])
                    self.selecting_identify()
                    self.driver.back()
                print("\n", "*" * 5, "Answers Matched of Identify", "*" * 5)
        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            self.driver.back()
            print("Error in View Identify")

    def edit_identify(self):
        """
        This function only edits identify questions sections and change the uploaded file and also change its text
        when a section is clicked like ID.AM first it matches URL
        """
        try:
            time.sleep(2)
            self.selecting_identify()
            self.common.wait.until(
                EC.visibility_of_element_located(
                    (By.CSS_SELECTOR, "#create_td_1 "))
            )

            # this will count total number of parts
            no_of_parts = self.driver.execute_script(
                'return document.querySelectorAll("#create_td_1 > tbody > tr > td > button ").length'
            )
            for i in range(no_of_parts):
                self.common.wait.until(
                    EC.element_to_be_clickable((By.ID, "a_1")))

                # this will click identify
                self.driver.execute_script(
                    'document.querySelector("#a_1").click()')
                time.sleep(1)

                # get part name that is inside identify
                part_name = self.driver.execute_script(
                    f'return document.querySelector("#create_td_1 > tbody > tr:nth-child({i+1}) > td.sorting_1 > span").textContent'
                )
                print("\nthis is the part name    :    ", part_name)

                # this will click on start button of each part
                self.driver.execute_script(
                    f'document.querySelector("tbody > tr:nth-child({i+1}) #submit-form1").click()'
                )

                # wait for complete page load
                self.common.wait.until(
                    EC.element_to_be_clickable(
                        (By.ID, "title_accordian1_label"))
                )

                # checks new page load
                if self.driver.current_url == NIST_MATCH_SINGLE_PART_URL:
                    time.sleep(2)

                    # total number of questions
                    number_of_questions = self.driver.execute_script(
                        'return document.querySelectorAll(".list-content").length'
                    )
                    if number_of_questions > 8:
                        print("number of questions greater than 8")
                        number_of_questions = 8

                    # this function will edit the record that is created
                    self.reg_common.each_edit_section(
                        number_of_questions, "identify")
                    self.driver.back()

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            self.driver.back()
            print("Error in Identify")

    def protect(self):
        """
        This function solves all questions sections of protect only by selecting each portion one by one
        """
        try:
            time.sleep(2)
            self.selecting_protect()
            self.common.wait.until(
                EC.visibility_of_element_located(
                    (By.CSS_SELECTOR, "#create_td_2"))
            )

            # this will count number of parts inside protect
            no_of_parts = self.driver.execute_script(
                'return document.querySelectorAll("#create_td_2 > tbody > tr > td > button ").length'
            )
            print("this is the number of parts", no_of_parts)

            for i in range(no_of_parts):
                time.sleep(2)
                self.selecting_protect()
                time.sleep(1)

                # this will get the part name that is inside identify
                part_name = self.driver.execute_script(
                    f'return document.querySelector("#create_td_2 > tbody > tr:nth-child({i+1}) > td.sorting_1 > span").textContent'
                )
                time.sleep(2)
                # this will click a part to give answer
                self.driver.execute_script(
                    f'document.querySelector("#create_td_2 tr[role=\\"row\\"]:nth-child({i+1}) button").click()'
                )
                time.sleep(3)

                # this will attach pollicy document
                self.reg_common.attach_policy_doc(self)
                print("\nthis is the part name    :\t", part_name)
                time.sleep(2)

                # number of questions inside each part
                number_of_questions = self.driver.execute_script(
                    'return document.querySelectorAll(".list-content").length'
                )
                if number_of_questions > 8:
                    print("number of questions greater than 8")
                    number_of_questions = 8
                for i in range(number_of_questions):
                    val = f"idam{i + 1}"

                    # this will fill the text and attach file as well
                    self.reg_common.form_fill(IDAM_VARIABLES[val])
                self.driver.back()

            print("\n", "*" * 5, "Successfully answered Protect", "*" * 5)
        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            self.driver.back()
            print("Error in Protect")

    def view_protect(self):
        try:
            time.sleep(2)
            self.selecting_protect()
            self.common.wait.until(
                EC.visibility_of_element_located(
                    (By.CSS_SELECTOR, "#create_td_2 "))
            )

            # this will count number of parts inside protect
            no_of_parts = self.driver.execute_script(
                'return document.querySelectorAll("#create_td_2 .sorting_1").length'
            )
            print("this is no of parts :    ", no_of_parts)
            for i in range(no_of_parts):
                time.sleep(1)
                # get part name that record is going to match
                part_name = self.driver.execute_script(
                    f'return document.querySelector("#create_td_2 > tbody > tr:nth-child({i+1}) > td.sorting_1 > span").textContent'
                )
                time.sleep(2)
                self.driver.execute_script(
                    f'document.querySelector("#create_td_2 > tbody > tr:nth-child({i+1}) #submit-form2").click()'
                )
                print("\nthis is the part name    :\t", part_name)
                time.sleep(2)

                # this will count total number of questions
                number_of_questions = self.driver.execute_script(
                    'return document.querySelectorAll(".list-content").length'
                )

                if number_of_questions > 8:
                    print("number of questions greater than 8")
                    number_of_questions = 8

                for i in range(number_of_questions):
                    val = f"form{i + 1}"

                    # this function will check all the details entered while creating audit
                    self.reg_common.check_form(CHECK_ATTRIBUTES[val])
                self.selecting_protect()
                self.driver.back()
        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            self.driver.back()
            print("\n\nError in View Protect")

    def edit_protect(self):
        try:
            time.sleep(2)
            self.selecting_protect()
            self.common.wait.until(
                EC.visibility_of_element_located(
                    (By.CSS_SELECTOR, "#create_td_2 "))
            )

            # this will count total number of parts
            no_of_parts = self.driver.execute_script(
                'return document.querySelectorAll("#create_td_2 > tbody > tr > td > button ").length'
            )

            for i in range(no_of_parts):
                self.common.wait.until(
                    EC.element_to_be_clickable((By.ID, "a_2")))

                # this will click protect
                self.driver.execute_script(
                    'document.querySelector("#a_2").click()')
                time.sleep(1)

                # get part name that is inside identify
                part_name = self.driver.execute_script(
                    f'return document.querySelector("#create_td_2 > tbody > tr:nth-child({i+1}) > td.sorting_1 > span").textContent'
                )
                print("\nthis is the part name    :    ", part_name)

                # it will then clicks on start button of each part
                self.driver.execute_script(
                    f'document.querySelector("tbody > tr:nth-child({i+1}) #submit-form2").click()'
                )

                # wait for complete page load
                self.common.wait.until(
                    EC.element_to_be_clickable(
                        (By.ID, "title_accordian1_label"))
                )

                # checks new page load
                if self.driver.current_url == NIST_MATCH_SINGLE_PART_URL:
                    # total number of questions
                    number_of_questions = self.driver.execute_script(
                        'return document.querySelectorAll(".list-content").length'
                    )
                    if number_of_questions > 8:
                        print("number of questions greater than 8")
                        number_of_questions = 8

                    # this function will edit the record that is created
                    self.reg_common.each_edit_section(
                        number_of_questions, "protect")
                    self.driver.back()

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            self.driver.back()
            print("Error in Protect")

    def detect(self):
        """
        This function solves all questions sections of detect only by selecting each portion one by one
        """
        try:
            time.sleep(2)
            self.selecting_detect()
            self.common.wait.until(
                EC.visibility_of_element_located(
                    (By.CSS_SELECTOR, "#create_td_3 "))
            )

            # this will count number of parts inside identify
            no_of_parts = self.driver.execute_script(
                'return document.querySelectorAll("#create_td_3 > tbody > tr > td > button ").length'
            )
            print("this is the number of parts", no_of_parts)
            for i in range(no_of_parts):
                time.sleep(2)
                self.selecting_detect()
                time.sleep(1)

                # this will get the part name that is inside identify
                part_name = self.driver.execute_script(
                    f'return document.querySelector("#create_td_3 > tbody > tr:nth-child({i+1}) > td.sorting_1 > span").textContent'
                )

                # this will click a part to give answer
                self.driver.execute_script(
                    f'document.querySelector("#create_td_3 tr[role=\\"row\\"]:nth-child({i+1}) button").click()'
                )
                time.sleep(3)

                # this will attach pollicy document
                self.reg_common.attach_policy_doc(self)
                print("\nthis is the part name    :\t", part_name)
                time.sleep(2)

                # number of questions inside each part
                number_of_questions = self.driver.execute_script(
                    'return document.querySelectorAll(".list-content").length'
                )
                if number_of_questions > 8:
                    print("number of questions greater than 8")
                    number_of_questions = 8
                for i in range(number_of_questions):
                    val = f"idam{i + 1}"

                    # this will fill the text and attach file as well
                    self.reg_common.form_fill(IDAM_VARIABLES[val])
                self.driver.back()

            print("\n", "*" * 5, "Successfully answered Detect", "*" * 5)
        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            self.driver.back()
            print("Error in Detect")

    def view_detect(self):
        try:
            time.sleep(2)
            self.selecting_detect()
            self.common.wait.until(
                EC.visibility_of_element_located(
                    (By.CSS_SELECTOR, "#create_td_3 "))
            )

            # this will count number of parts inside detect
            no_of_parts = self.driver.execute_script(
                'return document.querySelectorAll("#create_td_3 .sorting_1").length'
            )
            print("this is no of parts :    ", no_of_parts)
            for i in range(no_of_parts):
                time.sleep(1)
                # get part name that record is going to match
                part_name = self.driver.execute_script(
                    f'return document.querySelector("#create_td_3 > tbody > tr:nth-child({i+1}) > td.sorting_1 > span").textContent'
                )
                time.sleep(2)

                # this will click on view button
                self.driver.execute_script(
                    f'document.querySelector("#create_td_3 > tbody > tr:nth-child({i+1}) #submit-form3").click()'
                )
                print("\nthis is the part name    :\t", part_name)
                time.sleep(2)

                # this will count total number of questions
                number_of_questions = self.driver.execute_script(
                    'return document.querySelectorAll(".list-content").length'
                )

                if number_of_questions > 8:
                    print("number of questions greater than 8")
                    number_of_questions = 8

                for i in range(number_of_questions):
                    val = f"form{i + 1}"

                    # this function will check all the details entered while creating audit
                    self.reg_common.check_form(CHECK_ATTRIBUTES[val])
                self.selecting_detect()
                self.driver.back()

            print("\n", "*" * 5, "Answers Matched of Detect", "*" * 5)
        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            self.driver.back()
            print("Error in view detect")

    def edit_detect(self):
        try:
            time.sleep(2)
            self.selecting_detect()
            self.common.wait.until(
                EC.visibility_of_element_located(
                    (By.CSS_SELECTOR, "#create_td_3 "))
            )

            # this will count total number of parts
            no_of_parts = self.driver.execute_script(
                'return document.querySelectorAll("#create_td_3 > tbody > tr > td > button ").length'
            )
            time.sleep(2)
            for i in range(no_of_parts):
                self.common.wait.until(
                    EC.element_to_be_clickable((By.ID, "a_3")))

                # this will click detect
                self.driver.execute_script(
                    'document.querySelector("#a_3").click()')
                time.sleep(1)

                # get part name that is inside identify
                part_name = self.driver.execute_script(
                    f'return document.querySelector("#create_td_3 > tbody > tr:nth-child({i+1}) > td.sorting_1 > span").textContent'
                )
                print("\nthis is the part name    :    ", part_name)

                # this will click on start button of each part
                self.driver.execute_script(
                    f'document.querySelector("tbody > tr:nth-child({i+1}) #submit-form3").click()'
                )

                # wait for complete page load
                self.common.wait.until(
                    EC.element_to_be_clickable(
                        (By.ID, "title_accordian1_label"))
                )

                # checks new page load
                if self.driver.current_url == NIST_MATCH_SINGLE_PART_URL:
                    time.sleep(2)

                    # total number of questions
                    number_of_questions = self.driver.execute_script(
                        'return document.querySelectorAll(".list-content").length'
                    )
                    if number_of_questions > 8:
                        print("number of questions greater than 8")
                        number_of_questions = 8

                    # this function will edit the record that is created
                    self.reg_common.each_edit_section(
                        number_of_questions, "detect")
                    self.driver.back()

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            self.driver.back()
            print("Error in edit Detect")

    def recover(self):
        """
        This function solves all questions sections of recover only by selecting each portion one by one
        """
        try:
            time.sleep(2)
            self.selecting_recover()
            self.common.wait.until(
                EC.visibility_of_element_located(
                    (By.CSS_SELECTOR, "#create_td_4"))
            )

            # this will count number of parts inside recover
            no_of_parts = self.driver.execute_script(
                'return document.querySelectorAll("#create_td_4 > tbody > tr > td > button ").length'
            )
            print("this is the number of parts", no_of_parts)
            for i in range(no_of_parts):
                time.sleep(2)
                self.selecting_recover()
                time.sleep(1)

                # this will get the part name that is inside recover
                part_name = self.driver.execute_script(
                    f'return document.querySelector("#create_td_4 > tbody > tr:nth-child({i+1}) > td.sorting_1 > span").textContent'
                )

                # this will click a part to give answer
                self.driver.execute_script(
                    f'document.querySelector("#create_td_4 tr[role=\\"row\\"]:nth-child({i+1}) button").click()'
                )
                time.sleep(3)

                # this will attach pollicy document
                self.reg_common.attach_policy_doc(self)
                print("\nthis is the part name    :\t", part_name)
                time.sleep(2)

                # number of questions inside each part
                number_of_questions = self.driver.execute_script(
                    'return document.querySelectorAll(".list-content").length'
                )
                if number_of_questions > 8:
                    print("number of questions greater than 8")
                    number_of_questions = 8
                for i in range(number_of_questions):
                    val = f"idam{i + 1}"

                    # this will fill the text and attach file as well
                    self.reg_common.form_fill(IDAM_VARIABLES[val])
                self.driver.back()
            print("\n", "*" * 5, "Successfully answered Recover", "*" * 5)

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            self.driver.back()
            print("Error in Recover")

    def view_recover(self):
        try:
            time.sleep(2)
            self.selecting_recover()
            self.common.wait.until(
                EC.visibility_of_element_located(
                    (By.CSS_SELECTOR, "#create_td_4 "))
            )

            # this will count number of parts inside recover
            no_of_parts = self.driver.execute_script(
                'return document.querySelectorAll("#create_td_4 .sorting_1").length'
            )
            print("this is no of parts :    ", no_of_parts)
            for i in range(no_of_parts):
                time.sleep(1)
                # get part name that record is going to match
                part_name = self.driver.execute_script(
                    f'return document.querySelector("#create_td_4 > tbody > tr:nth-child({i+1}) > td.sorting_1 > span").textContent'
                )
                time.sleep(2)

                # this will click on view button
                self.driver.execute_script(
                    f'document.querySelector("#create_td_4 > tbody > tr:nth-child({i+1}) #submit-form4").click()'
                )
                print("\nthis is the part name    :\t", part_name)
                time.sleep(2)

                # this will count total number of questions
                number_of_questions = self.driver.execute_script(
                    'return document.querySelectorAll(".list-content").length'
                )

                if number_of_questions > 8:
                    print("number of questions greater than 8")
                    number_of_questions = 8

                for i in range(number_of_questions):
                    val = f"form{i + 1}"

                    # this function will check all the details entered while creating audit
                    self.reg_common.check_form(CHECK_ATTRIBUTES[val])
                self.selecting_recover()
                self.driver.back()

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            self.driver.back()
            print("\n\nError in View Recover")

    def edit_recover(self):
        try:
            time.sleep(2)
            self.selecting_recover()
            self.common.wait.until(
                EC.visibility_of_element_located(
                    (By.CSS_SELECTOR, "#create_td_4 "))
            )

            # this will count total number of parts
            no_of_parts = self.driver.execute_script(
                'return document.querySelectorAll("#create_td_4 > tbody > tr > td > button ").length'
            )
            time.sleep(no_of_parts)
            for i in range(no_of_parts):
                self.common.wait.until(
                    EC.element_to_be_clickable((By.ID, "a_4")))

                # this will click recover
                self.driver.execute_script(
                    'document.querySelector("#a_4").click()')
                time.sleep(1)

                # get part name that is inside recover
                part_name = self.driver.execute_script(
                    f'return document.querySelector("#create_td_4 > tbody > tr:nth-child({i+1}) > td.sorting_1 > span").textContent'
                )
                print("\nthis is the part name    :    ", part_name)

                # this will click on start button of each part
                self.driver.execute_script(
                    f'document.querySelector("#create_td_4 > tbody > tr:nth-child({i+1}) #submit-form4").click()'
                )

                # wait for complete page load
                self.common.wait.until(
                    EC.element_to_be_clickable(
                        (By.ID, "title_accordian1_label"))
                )

                # checks new page load
                if self.driver.current_url == NIST_MATCH_SINGLE_PART_URL:
                    print("opened edit page ")
                    time.sleep(2)

                    # total number of questions
                    number_of_questions = self.driver.execute_script(
                        'return document.querySelectorAll(".list-content").length'
                    )
                    if number_of_questions > 8:
                        print("number of questions greater than 8")
                        number_of_questions = 8

                    # this function will edit the record that is created
                    self.reg_common.each_edit_section(
                        number_of_questions, "recover")
                    self.driver.back()

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            self.driver.back()
            print("Error in Edit Recover")

    def respond(self):
        """
        This function solves all questions sections of respond only by selecting each portion one by one
        """
        try:
            time.sleep(2)
            self.selecting_respond()
            self.common.wait.until(
                EC.visibility_of_element_located(
                    (By.CSS_SELECTOR, "#create_td_5"))
            )

            # this will count number of parts inside respond
            no_of_parts = self.driver.execute_script(
                'return document.querySelectorAll("#create_td_5 > tbody > tr > td > button ").length'
            )
            print("this is the number of parts", no_of_parts)
            for i in range(no_of_parts):
                time.sleep(2)
                self.selecting_identify()
                time.sleep(1)

                # this will get the part name that is inside respond
                part_name = self.driver.execute_script(
                    f'return document.querySelector("#create_td_5 > tbody > tr:nth-child({i+1}) > td.sorting_1 > span").textContent'
                )
                time.sleep(3)

                # this will click a part to give answer
                self.driver.execute_script(
                    f'document.querySelector("#create_td_5 tr[role=\\"row\\"]:nth-child({i+1}) button").click()'
                )
                time.sleep(3)

                # this will attach pollicy document
                self.reg_common.attach_policy_doc(self)
                print("\nthis is the part name    :\t", part_name)
                time.sleep(2)

                # number of questions inside each part
                number_of_questions = self.driver.execute_script(
                    'return document.querySelectorAll(".list-content").length'
                )
                if number_of_questions > 8:
                    print("number of questions greater than 8")
                    number_of_questions = 8
                for i in range(number_of_questions):
                    val = f"idam{i + 1}"

                    # this will fill the text and attach file as well
                    self.reg_common.form_fill(IDAM_VARIABLES[val])
                self.driver.back()
            print("\n", "*" * 5, "Successfully answered Respond", "*" * 5)
        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            self.driver.back()
            print("Error in Respond")

    def view_respond(self):
        try:
            time.sleep(2)
            self.selecting_respond()
            self.common.wait.until(
                EC.visibility_of_element_located(
                    (By.CSS_SELECTOR, "#create_td_5 "))
            )

            # this will count number of parts inside identify
            no_of_parts = self.driver.execute_script(
                'return document.querySelectorAll("#create_td_5 .sorting_1").length'
            )
            print("this is no of parts :    ", no_of_parts)
            for i in range(no_of_parts):
                time.sleep(1)

                # get part name that record is going to match
                part_name = self.driver.execute_script(
                    f'return document.querySelector("#create_td_5 > tbody > tr:nth-child({i+1}) > td.sorting_1 > span").textContent'
                )
                time.sleep(2)

                # this will click on view button
                self.driver.execute_script(
                    f'document.querySelector("#create_td_5 > tbody > tr:nth-child({i+1}) #submit-form5").click()'
                )
                print("\nthis is the part name    :\t", part_name)
                time.sleep(2)

                # this will count total number of questions
                number_of_questions = self.driver.execute_script(
                    'return document.querySelectorAll(".list-content").length'
                )

                if number_of_questions > 8:
                    print("number of questions greater than 8")
                    number_of_questions = 8

                for i in range(number_of_questions):
                    val = f"form{i + 1}"
                    self.reg_common.check_form(CHECK_ATTRIBUTES[val])
                self.selecting_respond()
                self.driver.back()
        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            self.driver.back()
            print("Error in View Respond")

    def edit_respond(self):
        """
        This function only edits respond questions sections and change the uploaded file and also change its text
        """
        try:
            time.sleep(2)
            self.selecting_respond()
            self.common.wait.until(
                EC.visibility_of_element_located(
                    (By.CSS_SELECTOR, "#create_td_5 "))
            )

            # this will count total number of parts
            no_of_parts = self.driver.execute_script(
                'return document.querySelectorAll("#create_td_5 > tbody > tr > td > button ").length'
            )
            for i in range(no_of_parts):
                self.common.wait.until(
                    EC.element_to_be_clickable((By.ID, "a_5")))

                # this will click respond
                self.driver.execute_script(
                    'document.querySelector("#a_5").click()')
                time.sleep(1)

                # get part name that is inside respond
                part_name = self.driver.execute_script(
                    f'return document.querySelector("#create_td_5 > tbody > tr:nth-child({i+1}) > td.sorting_1 > span").textContent'
                )
                print("\nthis is the part name    :    ", part_name)

                # it will then select first form
                self.driver.execute_script(
                    f'document.querySelector("#create_td_5 > tbody > tr:nth-child({i+1}) #submit-form5").click()'
                )

                # wait for complete page load
                self.common.wait.until(
                    EC.element_to_be_clickable(
                        (By.ID, "title_accordian1_label"))
                )

                # checks new page load
                if self.driver.current_url == NIST_MATCH_SINGLE_PART_URL:
                    print("opened edit page ")
                    time.sleep(2)

                    # total number of questions
                    number_of_questions = self.driver.execute_script(
                        'return document.querySelectorAll(".list-content").length'
                    )
                    if number_of_questions > 8:
                        print("number of questions greater than 8")
                        number_of_questions = 8

                    self.reg_common.each_edit_section(
                        number_of_questions, "respond")
                    self.driver.back()

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            self.driver.back()
            print("Error in Edit Respond")

    def selecting_identify(self):
        """
        This is only used to click on identify
        """
        try:
            # Selecting Identify
            self.common.wait.until(
                EC.element_to_be_clickable((By.CSS_SELECTOR, "button#a_1"))
            )
            self.driver.find_element(By.CSS_SELECTOR, "button#a_1").click()
            self.basic = "document.querySelectorAll('tr td button#submit-form1')"
        except:
            print("identify not opened")

    def selecting_protect(self):
        """
        This is only used to click on protect
        """
        try:
            # wait until protect is line in clickable
            self.common.wait.until(
                EC.element_to_be_clickable((By.CSS_SELECTOR, "button#a_2"))
            )
            self.driver.find_element(By.CSS_SELECTOR, "button#a_2").click()
            print("opened protect")
            self.basic = "document.querySelectorAll('tr td button#submit-form2')"
        except:
            print("identify not opened")

    def selecting_detect(self):
        """
        This is only used to click on detect
        """
        try:
            # Selecting Identify
            self.common.wait.until(
                EC.element_to_be_clickable((By.CSS_SELECTOR, "button#a_3"))
            )
            self.driver.find_element(By.CSS_SELECTOR, "button#a_3").click()
            self.basic = "document.querySelectorAll('tr td button#submit-form3')"
        except:
            print("detect not opened")

    def selecting_recover(self):
        """
        This is only used to click on recover
        """
        try:
            # Selecting Identify
            self.common.wait.until(
                EC.element_to_be_clickable((By.CSS_SELECTOR, "button#a_4"))
            )
            self.driver.find_element(By.CSS_SELECTOR, "button#a_4").click()
            self.basic = "document.querySelectorAll('tr td button#submit-form4')"
        except:
            print("recover not opened")

    def selecting_respond(self):
        """
        This is only used to click on respond
        """
        try:
            # Selecting Identify
            self.common.wait.until(
                EC.element_to_be_clickable((By.CSS_SELECTOR, "button#a_5"))
            )
            self.driver.find_element(By.CSS_SELECTOR, "button#a_5").click()
            self.basic = "document.querySelectorAll('tr td button#submit-form5')"
        except:
            print("respond not opened")

    def action_perform(self):
        try:
            # # calling data partners and functionalities
            self.reg_common.search_by_audit()
            self.reg_common.go_to_data_partners()
            self.driver.back()
            self.reg_common.check_filter()

            # calling details page and functionalities
            # time.sleep(1)
            self.reg_common.search_by_audit()
            time.sleep(2)
            self.go_to_details()
            self.driver.back()

            # calling edit page and functionalities
            self.reg_common.search_by_audit()
            time.sleep(2)
            self.go_to_edit()
            self.driver.back()

            # calling dashboard page and functionalities
            self.reg_common.search_by_audit()
            time.sleep(2)
            self.reg_common.go_to_dashboard()
            self.driver.back()

            # removing record
            self.reg_common.search_by_audit()
            self.reg_common.remove_created_nist_audit()

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            print("Error in action perform function")

    def go_to_details(self):
        try:
            self.driver.execute_script(
                "document.querySelectorAll('ul.action-drop li a')[3].click()"
            )
            time.sleep(2)
            if self.driver.current_url == NIST_DETAILS_PAGE_URL:
                print(10 * "*", "Entered on Details", 10 * "*")
                # Questions
                self.view_identify()
                self.view_protect()
                self.view_detect()
                self.view_recover()
                self.view_respond()

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            print("Error in function go_to_details")

    def go_to_edit(self):
        try:
            try:
                # clicks the action button when single record found on search
                self.driver.execute_script(
                    'document.querySelector("#cratbody > tr > td:nth-child(7) > ul > li > a > button").click()'
                )
            except:
                # clicks the action button when multiple records found on search
                self.driver.execute_script(
                    'document.querySelector("#cratbody > tr:nth-child(1) > td:nth-child(7) > ul > li > a > button").click()'
                )
            time.sleep(2)

            # clicks on edit
            self.driver.execute_script(
                'document.querySelector("body > ul > li:nth-child(6) > a").click()'
            )

            time.sleep(2)

            # for clicking status after clicking edit
            self.driver.execute_script(
                'document.querySelector("#edit_modal_body > div:nth-child(4) > div > button > span.filter-option.pull-left").click()'
            )

            time.sleep(2)

            # this will selects status inprogress
            self.driver.execute_script(
                'document.querySelector("#edit_modal_body > div:nth-child(4) > div > div > ul > li:nth-child(2) > a").click()'
            )

            # this will sends reason
            # entering reason
            self.driver.execute_script(
                'document.querySelector("#last_reason").value = "Automate Edit" '
            )
            time.sleep(1)

            # activate the disabled save button
            self.driver.execute_script(
                'document.querySelector("#save_changes12").disabled=false;'
            )

            # clicks on save after entering reason
            self.driver.execute_script(
                'document.querySelector("#save_changes12").click()'
            )

            # then page opens of questions
            time.sleep(1)
            self.common.wait.until(EC.element_to_be_clickable((By.ID, "a_1")))
            if self.driver.current_url == NIST_EDIT_PAGE_URL:
                print(
                    "\n", 10 * "*", "Entered Edit Page***********************", 10 * "*"
                )
                print("matched url")
                self.edit_identify()
                self.edit_protect()
                self.edit_detect()
                self.edit_recover()
                self.edit_respond()

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            print("Error in function go_to_details")

    def check_status(self):
        "This function checks that lock file is present or not which means browser is running"
        if os.path.exists(self.lock_file_path):
            return "Already Created"
        else:
            # Create lock file
            open(self.lock_file_path, "w").close()
            return "Not Created"


if __name__ == "__main__":
    obj = NIST()
    obj.main()
