from constants_cytex import *
import time
from selenium.webdriver.common.by import By
import traceback
from selenium.webdriver.support import expected_conditions as EC
import os
from common_functionalities import CommonUsed
from RegulatoryCompliances.regulatory_common import Regulatory_Compliance_Common


class ISO:
    def __init__(self, driver=None) -> None:
        if driver is not None:
            self.driver = driver
            self.common = CommonUsed(driver)
        else:
            self.driver = None
            self.common = CommonUsed()
            # self.reg_common = Regulatory_Compliance_Common(self.driver)

        self.path = os.getcwd()
        self.path_docs = os.path.join(self.path, "docs")
        self.path = os.path.join(self.path, "txt")
        self.name = AUDIT_NAME
        # self.name = "TheresaBarton"
        self.name = str(self.name).replace(" ", "")
        self.name = str(self.name).replace(",", "")
        self.name = str(self.name).replace(".", "")
        self.name = str(self.name).replace("-", "")
        self.name = str(self.name).replace("_", "")

    def main(self):
        """
        This function is responsible for performing all tasks because in this we call the
        functionality that we need to automate if its function is already prepared and
        functioning properly.
        """
        try:
            self.lock_file_path = "lockfile.lock"

            status = self.check_status()
            ELEMENT_REGULATORY_COMPLIANCE = "ul li#regulatory_main a"
            ELEMENT_NIST = "ul.ml-menu.compliUl li a#nist"
            self.reg_comp_id = "compli"
            self.iso_page_id = "iso"
            if status != "Already Created":
                self.common.start()
                self.driver = self.common.driver
                print("entering to wait")
                self.common.wait.until(EC.element_to_be_clickable((By.NAME, "text")))
                # This function login user when passed credentials
                self.common.login_page(login_user_list[0])

            # This will redirect to regulatory page
            time.sleep(3)

            self.common.user_mgmt_path_sub_modules(
                self.reg_comp_id, self.iso_page_id, "regulatory_compliance", "iso"
            )
            print("path selected")
            self.reg_common = Regulatory_Compliance_Common(
                self.common.wait, self.driver, self.path, self.path_docs, self.name
            )
            time.sleep(1)
            self.iso_page()

            return self.driver

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )

    def iso_page(self):
        """
        This function have all main functionalities of iso page
        """
        try:
            time.sleep(2)

            if self.driver.current_url == NIST_PAGE_URL:
                self.create_iso_audit()
                self.driver.back()
                self.driver.back()
                # this function has all functionalities inside action button inside iso page
                self.action_perform()

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            print("Error in ISO page function")

    def start_audit(self):
        """
        This function is called when a audit has to fill a form before creating new audit
        """
        try:
            if self.driver.current_url == NIST_START_AUDIT_PAGE_URL:
                print("this is audit name : ", self.name)
                address = AUDIT_ADDRESS
                self.driver.find_element(
                    By.CSS_SELECTOR, "div input#auditName"
                ).send_keys(self.name)
                self.driver.find_element(
                    By.CSS_SELECTOR, "div input#company_name"
                ).send_keys("MSFT")
                self.driver.find_element(
                    By.CSS_SELECTOR, "div input#company_ddress"
                ).send_keys(address)
                self.driver.find_element(
                    By.CSS_SELECTOR, "button#submit_audit_btn"
                ).click()
                time.sleep(2)
        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )

    def create_iso_audit(self):
        """
        This function creates audit for iso
        """
        try:
            self.driver.find_element(By.CSS_SELECTOR, "div#m_top a img").click()
            time.sleep(3)
            self.start_audit()
            if self.driver.current_url == NIST_CREATE_AUDIT_PAGE_URL:
                print("\n", "*" * 10, "Entered Create ISO Page", "*" * 10)
                self.iso_all_controlls()
                print("All Questions are answered\n")
            else:
                print("Url not matched")

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            print("Error in creating iso audit")

    def iso_all_controlls(self):
        """
        This function will select every control
        1) Selects every part inside a control one by one
        2) Display a part name before clicking on it
        3) Attach policy document and download as well
        4) Also do upload policy functionalities
        3) Answer every question
        4) Attach file with every question
        """
        try:
            time.sleep(2)
            # this will tell the length of all controlls
            length_controlls = self.driver.execute_script(
                'return document.querySelectorAll(".row.clearfix").length'
            )
            length_controlls = 3
            for index_control in range(1, length_controlls):
                time.sleep(4)
                self.common.wait.until(
                    EC.visibility_of_element_located(
                        (By.CSS_SELECTOR, f"button#a_{index_control}")
                    )
                )
                self.common.wait.until(
                    EC.element_to_be_clickable(
                        (By.CSS_SELECTOR, f"button#a_{index_control}")
                    )
                )

                # this will show the control name before clicking on it
                control_name = self.driver.find_element(
                    By.CSS_SELECTOR, f"button#a_{index_control}"
                ).text
                print("this is the control name :   ", control_name)
                self.driver.find_element(
                    By.CSS_SELECTOR, f"button#a_{index_control}"
                ).click()

                # this will count number of parts inside identify
                no_of_parts = self.driver.execute_script(
                    f'return document.querySelectorAll("#create_td_{index_control} > tbody > tr > td > button ").length'
                )
                # no_of_parts = 3
                for index_part in range(1, no_of_parts):
                    time.sleep(2)
                    self.each_part(index_control, index_part)

            print("\n", "*" * 5, "Successfully answered for All Questions", "*" * 5)
        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            self.driver.back()
            print("Error in iso_all_controlls")

    def each_part(self, index_control, index_part):
        """
        This function do these tasks
        1) Get part name
        2) Click each part which index is passed as a parameter
        3) this function do attach pollicy work
        """
        try:
            self.common.wait.until(
                EC.element_to_be_clickable(
                    (By.CSS_SELECTOR, f"button#a_{index_control}")
                )
            )
            self.driver.find_element(
                By.CSS_SELECTOR, f"button#a_{index_control}"
            ).click()

            time.sleep(3)

            # this will get the part name that is inside identify
            part_name = self.driver.execute_script(
                f'return document.querySelector("#create_td_{index_control} > tbody > tr:nth-child({index_part}) > td.sorting_1 > span").textContent'
            )

            # this will click a part to give answer
            self.driver.execute_script(
                f'document.querySelector("#create_td_{index_control} tr[role=\\"row\\"]:nth-child({index_part}) button").click()'
            )
            time.sleep(3)

            print("\nthis is the part name    :\t", part_name)
            # this will attach pollicy document
            self.reg_common.attach_policy_doc()
            time.sleep(2)

            # number of questions inside each part
            number_of_questions = self.driver.execute_script(
                'return document.querySelectorAll(".list-content").length'
            )
            if number_of_questions > 8:
                print("number of questions greater than 8")
                number_of_questions = 8
            for index_question in range(number_of_questions):
                val = f"idam{index_question + 1}"

                # this will fill the text and attach file as well
                self.reg_common.form_fill(IDAM_VARIABLES[val])
            print("\tThis part questions are answered")
            self.driver.back()
        except Exception as e:
            # print(
            #     type(e).__name__,  # TypeError
            #     e.__traceback__.tb_lineno,  # 2
            #     traceback.format_exc(),
            # )
            self.driver.back()
            print("Error in each part function")

    def action_perform(self):
        try:
            self.reg_common.search_by_audit()
            time.sleep(2)
            self.go_to_details()
            self.driver.back()
            time.sleep(2)

            self.reg_common.search_by_audit()
            self.go_to_edit()
            self.driver.back()
            time.sleep(3)

            self.reg_common.search_by_audit()
            self.reg_common.remove_created_nist_audit()
            time.sleep(3)
        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            self.driver.back()
            print("error in action perform")

    def go_to_details(self):
        try:
            time.sleep(3)
            self.driver.execute_script(
                'document.querySelector("#cratbody > tr:nth-child(1) > td:nth-child(7) > ul > li > a > button").click()'
            )
            self.driver.execute_script(
                'document.querySelector("body > ul > li:nth-child(4) > a").click()'
            )

            if self.driver.current_url == NIST_DETAILS_PAGE_URL:
                time.sleep(3)
                print("matched URL")
                # this will tell the length of all controlls
                length_controlls = self.driver.execute_script(
                    'return document.querySelectorAll(".row.clearfix").length'
                )

                # length_controlls = 3
                for index_control in range(1, 4):
                    print("entered for loop")
                    time.sleep(2)
                    self.common.wait.until(
                        EC.element_to_be_clickable(
                            (By.CSS_SELECTOR, f"button#a_{index_control}")
                        )
                    )

                    control_name = self.driver.find_element(
                        By.CSS_SELECTOR, f"button#a_{index_control}"
                    ).text
                    print("this is the control name :   ", control_name)

                    self.driver.find_element(
                        By.CSS_SELECTOR, f"button#a_{index_control}"
                    ).click()

                    self.each_detail(index_control)
                print("\n", "*" * 5, "All Answers are Checked", "*" * 5)
            else:
                print("URL not matched")

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            self.driver.back()

    def each_detail(self, index_control):
        try:
            time.sleep(2)
            self.common.wait.until(
                EC.visibility_of_element_located(
                    (By.CSS_SELECTOR, f"#create_td_{index_control}")
                )
            )

            # this will count number of parts inside identify
            no_of_parts = self.driver.execute_script(
                f'return document.querySelectorAll("#create_td_{index_control} .sorting_1").length'
            )
            print("this is no of parts :    ", no_of_parts)
            if no_of_parts > 0:
                for index_part in range(1):
                    self.common.wait.until(
                        EC.element_to_be_clickable(
                            (By.CSS_SELECTOR, f"button#a_{index_control}")
                        )
                    )
                    self.driver.find_element(
                        By.CSS_SELECTOR, f"button#a_{index_control}"
                    ).click()
                    time.sleep(1)

                    # get part name that record is going to match
                    part_name = self.driver.execute_script(
                        f'return document.querySelector("#create_td_{index_control} > tbody > tr:nth-child({index_part+1}) > td.sorting_1 > span").textContent'
                    )
                    time.sleep(2)

                    # this will click on view button
                    self.driver.execute_script(
                        f'document.querySelector("#create_td_{index_control} > tbody > tr:nth-child({index_part+1}) #submit-form{index_control}").click()'
                    )
                    print("\nthis is the part name    :\t", part_name)
                    time.sleep(2)

                    # this will count total number of questions
                    number_of_questions = self.driver.execute_script(
                        'return document.querySelectorAll(".list-content").length'
                    )

                    if number_of_questions > 8:
                        print("number of questions greater than 8")
                        number_of_questions = 8

                    for index_question in range(number_of_questions):
                        val = f"form{index_question + 1}"

                        # this function will check all the details entered while creating audit
                        self.reg_common.check_form(CHECK_ATTRIBUTES[val])
                    self.driver.back()

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            self.driver.back()
            print("Error in View Identify")

    def go_to_edit(self) -> None:
        try:
            time.sleep(4)
            print(10 * "*", "ENTERED EDIT ISO", 10 * "*")
            try:
                # clicks the action button when single record found on search
                self.driver.execute_script(
                    'document.querySelector("#cratbody > tr > td:nth-child(7) > ul > li > a > button").click()'
                )
            except:
                # clicks the action button when multiple records found on search
                self.driver.execute_script(
                    'document.querySelector("#cratbody > tr:nth-child(1) > td:nth-child(7) > ul > li > a > button").click()'
                )
            time.sleep(2)
            # clicks on edit
            self.driver.execute_script(
                'document.querySelector("body > ul > li:nth-child(6) > a").click()'
            )
            self.reg_common.giving_reason_edit()
            time.sleep(4)

            if self.driver.current_url == NIST_EDIT_PAGE_URL:
                time.sleep(1)
                print("matched URL")
                # this will tell the length of all controlls
                length_controlls = self.driver.execute_script(
                    'return document.querySelectorAll(".row.clearfix").length'
                )

                length_controlls = 4
                for index_control in range(1, length_controlls):
                    print("entered for loop")
                    time.sleep(4)
                    self.common.wait.until(
                        EC.element_to_be_clickable(
                            (By.CSS_SELECTOR, f"button#a_{index_control}")
                        )
                    )

                    control_name = self.driver.find_element(
                        By.CSS_SELECTOR, f"button#a_{index_control}"
                    ).text
                    print("this is the control name :   ", control_name)

                    # self.driver.find_element(
                    #     By.CSS_SELECTOR, f"button#a_{index_control}"
                    # ).click()

                    self.each_edit(index_control)

                print("\n", "*" * 5, "All Answers are Checked", "*" * 5)
            else:
                print("URL not matched")

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            self.driver.back()

    def each_edit(self, index_control):
        try:
            time.sleep(2)
            self.driver.find_element(
                By.CSS_SELECTOR, f"button#a_{index_control}"
            ).click()
            self.common.wait.until(
                EC.visibility_of_element_located(
                    (By.CSS_SELECTOR, f"#create_td_{index_control} ")
                )
            )

            # this will count total number of parts
            no_of_parts = self.driver.execute_script(
                f'return document.querySelectorAll("#create_td_{index_control} > tbody > tr > td > button ").length'
            )
            time.sleep(no_of_parts)
            for index_part in range(no_of_parts):
                self.common.wait.until(
                    EC.element_to_be_clickable((By.ID, f"a_{index_control}"))
                )

                # this will click recover
                self.driver.execute_script(
                    f'document.querySelector("#a_{index_control}").click()'
                )
                time.sleep(1)

                # get part name that is inside recover
                part_name = self.driver.execute_script(
                    f'return document.querySelector("#create_td_{index_control} > tbody > tr:nth-child({index_part+1}) > td.sorting_1 > span").textContent'
                )
                print("\nthis is the part name    :    ", part_name)
                time.sleep(1)
                # this will click on start button of each part
                self.driver.execute_script(
                    f'document.querySelector("#create_td_{index_control} > tbody > tr:nth-child({index_part+1}) #submit-form{index_control}").click()'
                )

                # wait for complete page load
                self.common.wait.until(EC.element_to_be_clickable((By.ID, "child")))

                time.sleep(2)
                # checks new page load
                if self.driver.current_url == NIST_MATCH_SINGLE_PART_URL:
                    time.sleep(1)
                    # total number of questions
                    number_of_questions = self.driver.execute_script(
                        'return document.querySelectorAll(".list-content").length'
                    )
                    if number_of_questions > 8:
                        print("number of questions greater than 8")
                        number_of_questions = 8

                    # this function will edit the record that is created
                    self.reg_common.each_edit_section(number_of_questions, "recover")
                    self.driver.back()
        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            self.driver.back()

    def check_status(self):
        "This function checks that lock file is present or not which means browser is running"
        if os.path.exists(self.lock_file_path):
            return "Already Created"
        else:
            # Create lock file
            open(self.lock_file_path, "w").close()
            return "Not Created"


if __name__ == "__main__":
    obj = ISO()
    obj.main()
