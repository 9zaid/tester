import requests
import random
import string
from faker import Faker
import os
import random_functions
from dotenv import load_dotenv
from datetime import datetime


load_dotenv()

# URLS
LOGIN_PAGE_URL = "https://uistage.cytex.io/accounts.html"
LANDING_PAGE_URL = "https://uistage.cytex.io/index.html"

# User Management URLS
CREATE_USER_PAGE_URL = "https://uistage.cytex.io/UserManagement/create_user.html"
MFA_PAGE_URL = "https://uistage.cytex.io/UserManagement/authentication.html"
USER_GROUP_PAGE_URL = "https://uistage.cytex.io/UserManagement/sso_groups.html"
WORKFLOWS_PAGE_URL = "https://uistage.cytex.io/UserManagement/workflow.html"
SSO_APPS_PAGE_URL = "https://uistage.cytex.io/UserManagement/auth_apps.html"
CONFIGURATION_PAGE_URL = "https://uistage.cytex.io/UserManagement/user_details.html"
HRIS_CONFIGURATION_PAGE_URL = "https://uistage.cytex.io/UserManagement/hr_configuration.html"
SMTP_CONFIGURATION_PAGE_URL = "https://uistage.cytex.io/UserManagement/smtp_configuration.html"

# Network Traffic Urls
NETWORK_PAGE_URL = "https://uistage.cytex.io/NetworkTraffic/network_traffic.html"
DATA_DESTINATION_PAGE_URL = "https://uistage.cytex.io/NetworkTraffic/data_destinations.html"
DATA_SOURCES_PAGE_URL = "https://uistage.cytex.io/NetworkTraffic/incoming.html"
POLICY_MANAGEMENT_PAGE_URL = "https://uistage.cytex.io/NetworkTraffic/policy.html"

# Rgulatory Compliance
NIST_PAGE_URL = "https://uistage.cytex.io/RegulatoryCompliance/rc_inventory.html"
NIST_START_AUDIT_PAGE_URL = "https://uistage.cytex.io/RegulatoryCompliance/rc_start_audit.html"
NIST_CREATE_AUDIT_PAGE_URL = "https://uistage.cytex.io/RegulatoryCompliance/rc_all_controls.html"
NIST_DATA_PARTNERS_PAGE_URL = "https://uistage.cytex.io/RegulatoryCompliance/rc_data_partners_detail.html"
NIST_DATA_DASHBOARD_URL = "https://uistage.cytex.io/RegulatoryCompliance/rc_new_dashboard.html"
NIST_DETAILS_PAGE_URL = "https://uistage.cytex.io/RegulatoryCompliance/rc_detailview_all_controls.html"
NIST_EDIT_PAGE_URL = "https://uistage.cytex.io/RegulatoryCompliance/rc_all_controls.html"
NIST_MATCH_SINGLE_PART_URL = "https://uistage.cytex.io/RegulatoryCompliance/rc_control.html"
NIST_MATCH_AUTOMATED_REPORT_PAGE_URL = "https://uistage.cytex.io/RegulatoryCompliance/rc_automated_report_details.html"

AUDIFY_PAGE_URL = "https://uistage.cytex.io/MyCompliance/custom_controls_inventory.html"
AUDIFY_ADD_CONTROL_PAGE_URL = "https://uistage.cytex.io/MyCompliance/add_custom_control.html"
AUDIFY_EDIT_PAGE_URL = "https://uistage.cytex.io/MyCompliance/edit_custom_control.html"
AUDIFY_FRAMEWORK_PAGE_URL = "https://uistage.cytex.io/MyCompliance/custom_frameworks_inventory.html"
AUDIFY_FRAMEWORK_ADD_PAGE_URL = "https://uistage.cytex.io/MyCompliance/add_custom_framework.html"
# LOGIN_User_CREDENTIALS at uistage.cytex.io
login_user_list = [{"username": os.getenv('LOGIN_USERNAME'),
                    "email": os.getenv('EMAIL'), "password": os.getenv('PASSWORD')}]

LOGIN_PAGE_ID = ""
LANDING_PAGE_ID = ""
USER_GROUP_PAGE_ID = ""

now = datetime.now()
print("now  :   ", now)
dt_string = now.strftime("%d-%m-%Y_%H:%M:%S")


RESULT_FILE_NAME = "result " + dt_string + ".json"

LANDING_PAGE_NAME = ""
LOGIN_PAGE_NAME = ""
USER_GROUP_PAGE_NAME = ""

DOWNLOAD_DIR = os.path.expanduser("~/Downloads")


# create user
Element_User_Mgmt = "userMgmt"
User_Mgmt_sub_Components = {"create_user": "create_user",
                            "mfa": "user_mfa", "user_group": "sso_groups", "config": "user_config"}

BUTTONS = {"sign_in_btn": "", "create_user_btn": ""}

faker = Faker()

CREATE_USER = [{"first_name": faker.first_name(), "last_name": "Khan", "username": random_functions.generate_username(), "password": os.getenv('PASSWORD'), "confirm_password": os.getenv('PASSWORD'),
                "functional_area": "New functional", "email": os.getenv('CREATE_USER_EMAIL')}]

CREATE_USER_BY_PLACEHOLDER = {"first_name": "First name *", "last_name": "Last name *", "username": "Username *", "password": "Password *", "confirm_password": "Confirm password *",
                              "functional_area": "Functional Area", "email": "Email *", "allowed_modules": "Allowed modules *", "modules_access_control": "", "user_group": "user_group"}

ALLOWED_MODULES_BY_ID = {"main": "Allowed modules *", "network_traffic": " NetworkTraffic", "cloud_apps": " CloudApps", "data_supply_chain": " DataSupplyChain", "user_management": " UserManagement", "cloud_security_posture": " CloudSecurityPosture",
                         "cytex_secure": " CytexSecure", "reports": " Reports", "configuration": " Configuration", "phishing": " PhishingSimulator", "regulatory": " RegulatoryCompliance", "system_integration": " SystemIntegration", "edr": "EDR", "syslog": "Syslog"}

# USER_MANAGEMENT_SUB_MODULES = ["create_user", "config", "user_group"]
MODULES = {"user_management": ["create_user", "config", "user_group"], "regulatory_compliance":["nist","ccpa","cmmc", "iso", "hipa", "nist"]}

url = "https://www.randomlists.com/data/words.json"
response = requests.get(url)

# COMMON_ELEMENTS_ID = {"search": "Search...", "filter": "create_td"}

if response.status_code == 200:
    data = response.json()
    words = data["data"]
    random_word = random.choice(words)
    print("This is the random word  :   ", random_word)
else:
    print("Failed to retrieve words")

# url = "https://api.quotable.io/random"  
url = "https://type.fit/api/quotes"   
try:
    response = requests.get(url)
except:
    print("response not fecthed from url constants")

data = ['Genius is one percent inspiration and ninety-nine percent perspiration.', 'You can observe a lot just by watching.', 'A house divided against itself cannot stand.', 'Difficulties increase the nearer we get to the goal.', 'Fate is in your hands and no one elses', 'Be the chief but never the lord.', 'Nothing happens unless first we dream.', 'Well begun is half done.', 'Life is a learning experience, only if you learn.', 'Self-complacency is fatal to progress.', 'Peace comes from within. Do not seek it without.', 'What you give is what you get.', 'We can only learn to love by loving.', 'Life is change. Growth is optional. Choose wisely.', "You'll see it when you believe it.", 'Today is the tomorrow we worried about yesterday.']

sentence = random.choice(data)
print("this is the data", sentence)


USER_GROUP_ELEMENTS = {}
CREATE_USER_GROUP = {
    "group_name": faker.first_name(), "group_desc": sentence}
CREATE_GROUP_ELEMENTS = {"group_name": "Group name", "group_desc": "Group description", "submit_btn": "create_btn"}


IDAM_VARIABLES = {"idam1": {"select": "title_accordian0_label", "file_element": "fileupload0", "file": "idam1.txt", "text_element": "body#tinymce p", "text": "This is idam 1", "text_box": "mytextarea_0_ifr", "save_button": "save_changes0"}, "idam2": {"select": "title_accordian1_label", "file_element": "fileupload1", "file": "idam2.txt", "text_element": "", "text": "This is idam 2", "text_box": "mytextarea_1_ifr", "save_button": "save_changes1"}, "idam3": {"select": "title_accordian2_label", "file_element": "fileupload2", "file": "idam3.txt", "text_element": "", "text": "This is idam 3", "text_box": "mytextarea_2_ifr", "save_button": "save_changes2"}, "idam4": {"select": "title_accordian3_label", "file_element": "fileupload3", "file": "idam4.txt", "text_element": "", "text": "This is idam 4", "text_box": "mytextarea_3_ifr", "save_button": "save_changes3"}, "idam5": {
    "select": "title_accordian4_label", "file_element": "fileupload4", "file": "idam5.txt", "text_element": "", "text": "This is idam 5", "text_box": "mytextarea_4_ifr", "save_button": "save_changes4"}, "idam6": {"select": "title_accordian5_label", "file_element": "fileupload5", "file": "idam6.txt", "text_element": "", "text": "This is idam 6", "text_box": "mytextarea_5_ifr", "save_button": "save_changes5"}, "idam7": {"select": "title_accordian6_label", "file_element": "fileupload6", "file": "idam7.txt", "text_element": "", "text": "This is idam 6", "text_box": "mytextarea_6_ifr", "save_button": "save_changes6"}, "idam8": {"select": "title_accordian7_label", "file_element": "fileupload7", "file": "idam7.txt", "text_element": "", "text": "This is idam 7", "text_box": "mytextarea_7_ifr", "save_button": "save_changes7"}}

CHECK_ATTRIBUTES = {"form1": {"select": "title0accordian_label", "file": "idam1.txt", "text": "added", "text_var": "#mytextarea_0 > p", "child": 1}, "form2": {"select": "title1accordian_label", "file": "idam2.txt", "text": "added", "text_var": "#mytextarea_1 > p", "child": 2}, "form3": {"select": "title2accordian_label", "file": "idam3.txt", "text": "added", "text_var": "#mytextarea_2 > p", "child": 3}, "form4": {"select": "title3accordian_label", "file": "idam4.txt", "text": "added", "text_var": "#mytextarea_3 > p", "child": 4}, "form5": {"select": "title4accordian_label", "file": "idam5.txt", "text": "added", "text_var": "#mytextarea_4 > p", "child": 5}, "form6": {"select": "title5accordian_label", "file": "idam6.txt", "text": "added", "text_var": "#mytextarea_5 > p", "child": 6}, "form7": {"select": "title6accordian_label", "file": "idam7.txt", "text": "added", "text_var": "#mytextarea_6 > p", "child": 7}, "form8": {"select": "title7accordian_label", "file": "idam8.txt", "text": "added", "text_var": "#mytextarea_7 > p", "child": 8}
                    }


EDIT_ATTRIBUTES = {"form1": {"select": "title_accordian0_label", "file": "idam1.txt", "text": "added", "text_var": "#mytextarea_0 > p", "child": 1, "text_box": "mytextarea_0_ifr", "save_button": "save_changes0", "file_element": "fileupload0"}, "form2": {"select": "title_accordian1_label", "file": "idam2.txt", "text": "added", "text_var": "#mytextarea_1 > p", "child": 2, "text_box": "mytextarea_1_ifr", "save_button": "save_changes1", "file_element": "fileupload1"}, "form3": {"select": "title_accordian2_label", "file": "idam3.txt", "text": "added", "text_var": "#mytextarea_2 > p", "child": 3, "text_box": "mytextarea_2_ifr", "save_button": "save_changes2", "file_element": "fileupload2"}, "form4": {"select": "title_accordian3_label", "file": "idam4.txt", "text": "added", "text_var": "#mytextarea_3 > p", "child": 4, "text_box": "mytextarea_3_ifr", "save_button": "save_changes3", "file_element": "fileupload3"}, "form5": {"select": "title_accordian4_label", "file": "idam5.txt", "text": "added", "text_var": "#mytextarea_4 > p", "child": 5, "text_box": "mytextarea_4_ifr", "save_button": "save_changes4", "file_element": "fileupload4"}, "form6": {"select": "title_accordian5_label", "file": "idam6.txt", "text": "added", "text_var": "#mytextarea_5 > p", "child": 6, "text_box": "mytextarea_5_ifr", "save_button": "save_changes5", "file_element": "fileupload5"}, "form7": {"select": "title_accordian6_label", "file": "idam7.txt", "text": "added", "text_var": "#mytextarea_6 > p", "child": 7, "text_box": "mytextarea_6_ifr", "save_button": "save_changes6", "file_element": "fileupload6"}, "form8": {"select": "title_accordian7_label", "file": "idam8.txt", "text": "added", "text_var": "#mytextarea_7 > p", "child": 8, "text_box": "mytextarea_7_ifr", "save_button": "save_changes7", "file_element": "fileupload7"}
                   }

AUDIT_NAME = faker.name()
AUDIT_ADDRESS = faker.address()
