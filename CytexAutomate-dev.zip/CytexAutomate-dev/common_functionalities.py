import time
import traceback
from constants_cytex import *
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from selenium import webdriver
import json

class CommonUsed():
    def __init__(self, driver=None) -> None:
        self.options = webdriver.ChromeOptions()
        if driver is not None:
            self.driver = driver
            self.wait = WebDriverWait(self.driver, 30)
        else:
            self.driver = None
            self.wait = None
        self.first_name = CREATE_USER[0]["first_name"]
        self.username = CREATE_USER[0]["username"].lower()

    def start(self):
        try:
            time.sleep(2)
            self.options = webdriver.ChromeOptions()
            print("Browser is not already running")
            self.options.add_experimental_option('detach', True)
            self.options.add_argument(
                "--disable-blink-features=AutomationControlled")
            prefs = {"download.default_directory": DOWNLOAD_DIR}

            # Allow multiple file downloads
            prefs["profile.default_content_setting_values.automatic_downloads"] = 1
            # Add preferences to Chrome options
            self.options.add_experimental_option("prefs", prefs)

            time.sleep(2)
            # If successful, the browser is not already running
            self.driver = webdriver.Chrome(options=self.options)
            self.driver.maximize_window()
            self.wait = WebDriverWait(self.driver, 20)
            
            # This will hit api and get response
            self.get_response_from_api(LANDING_PAGE_URL)


        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            print("ERROR in Start")

    def get_response_from_api(self, main_url: str) -> None:
        """
        This function is used to hit url and driver save respoonse inside it. After
        that if we want to pick any element then we will find that in driver 

        main_url -> string which is saved inside constant file
        """
        try:
            self.driver.get(main_url)
        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            print("Main request is not successfull")

    def login_page(self, login_user: dict) -> None:
        """
        This function is used to login user and it require a user credentials dictionary
        you like to sign in

        login_user -> It contains credentials of user which needs to be login 
        """
        try:
            if self.driver.current_url == LOGIN_PAGE_URL:
                self.driver.find_element(By.NAME, "text").send_keys(
                    login_user["username"])
                self.driver.find_element(By.NAME, "password").send_keys(
                    login_user["password"])
                self.driver.find_element(By.ID, "signin-form").click()
                
            else:
                print("URL is not matched")
        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            print("Error in login page")

    def user_mgmt_path_sub_modules(self, main_mod_id: str, sub_component: dict, module_name,  sub_module_name: str) -> None:
        """
        This function is just used to open the create_user page and it does not any 
        concern with the creation of user

        main_mod_id -> It is the id of main modules like user management, regulatory compliance
        sub_component -> It contains the id of sub component of main module
        module_name -> This is string, this function is generic and used to identify that 
        which page and sub_module creates error

        """
        try:
            # print(
            #     "\n*************************ENTERED USER MGMT PATH*******************\n")
            # this will wait until sidebar fully opens
            time.sleep(3)
            self.wait.until(EC.element_to_be_clickable(
                (By.CSS_SELECTOR, '.bars')))

            # This open sidebar
            self.driver.execute_script(
                "document.querySelector('.bars').click();")

            time.sleep(1)
            if sub_module_name == "nist_sp":
                try:
                    self.wait.until(
                        EC.element_to_be_clickable((By.ID, main_mod_id)))

                    # this will click on userManagement/Regulatory COmpliance
                    self.driver.find_element(By.ID, main_mod_id).click()

                    # wait for child to be prominent
                    self.wait.until(EC.element_to_be_clickable(
                        (By.ID, sub_component)))

                    self.driver.execute_script(
                        f'document.querySelectorAll("#{sub_component}")[1].click()')
                except:
                    self.wait.until(EC.element_to_be_clickable(
                        (By.ID, sub_component)))
                    self.driver.execute_script(
                        f'document.querySelectorAll("#{sub_component}")[1].click()')
            
            # if sub_module_name in MODULES[module_name]:
            try: 
                module_selected = self.driver.execute_script('return document.querySelector(".toggled span").textContent')
                if module_selected == module_name:
                    time.sleep(2)
                    self.driver.execute_script(
                            'document.querySelector(\'[id="{}"]\').click()'.format(sub_component))
            except:
            # else:
                # try:
                self.wait.until(
                    EC.element_to_be_clickable((By.ID, main_mod_id)))

                # this will click on userManagement/Regulatory COmpliance
                self.driver.find_element(By.ID, main_mod_id).click()
                print("step 2")
                # wait
                self.wait.until(EC.element_to_be_clickable(
                    (By.ID, sub_component)))
                print("step 3")
                # create_user/nist/config/OFDS
                self.driver.execute_script(
                    'document.querySelector(\'[id="{}"]\').click()'.format(sub_component))
                print("step 4")
                # except:
                #     print("step 5")
                #     self.wait.until(EC.element_to_be_clickable(
                #         (By.ID, sub_component)))
                #     self.driver.execute_script(
                #         'document.querySelector(\'[id="{}"]\').click()'.format(sub_component))

            time.sleep(2)
        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            print("***********Error in path to {}".format(sub_module_name))

    def check_records(self, number_col: int, data: dict, mode_name: str):
        """
        This is a generic function that is used to perform
        1) gets records list and count the list
        2) Page records increased when list is greater than 10
        3) Match below table mentioned total records with gets total records by automation
        4) If it doesn't match then generate a print
        """
        try:
            print("entered check records")
            # Getting all records
            records_before_create = self.driver.execute_script(
                "return document.querySelector('tbody').querySelectorAll('input')")
            total_records_first_page = len(records_before_create)/number_col
            print("total number of records of first page ",
                  total_records_first_page)

            # the line below table which tells total_records
            total_records = self.driver.execute_script(
                "return document.querySelector('div.dataTables_info').querySelector('b').textContent")
            total_records = int(total_records)
            print("overall total records    :   ", total_records)

            # This function checks total records are they greater than 10
            if total_records > 10:
                "Increase the size of records"
                print("total records of user groups are greater than 10")
                ele_page_records = "time_filter"
                self.page_records_to_100(ele_page_records)
                time.sleep(3)
                records_before_create = self.driver.execute_script(
                    "return document.querySelector('tbody').querySelectorAll('input')")

                total_records_first_page = len(
                    records_before_create)/number_col

            if (total_records_first_page) != total_records:
                print("Table below line which tells total record doesn't match")
                data["UserManagement"][mode_name]["match_rows_and_number"] = "failed"
                self.update_result(data)
                
            elif (total_records_first_page) == total_records:
                print("number of rows equal to below given")
                data["UserManagement"][mode_name]["match_rows_and_number"] = "successfull"
                self.update_result(data)
            else: 
                print("this is the else part")
            return records_before_create, total_records

        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            print("error in configuration page")
            self.existing_data[mode_name]["error"].append("error in matching rows with given number below")

    def page_records_to_100(self, element: str):
        """
        This function selects 100 page records it is called only when page records are greater than 10
        """
        try:
            self.driver.execute_script(
                'document.querySelector(\'button[data-id="{}"]\').click()'.format(element))
            time.sleep(4)
            selecting_page_records = self.driver.find_element(
                By.CSS_SELECTOR, '#filt_result ul.dropdown-menu.inner li[data-original-index ="3"] a')

            selecting_page_records.click()
        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            print("Error in filter function")

    def check_filter(self, text: str, element: str, mode_name: str):
        """
        element -> string -> which will use to find search element
        text -> string -> Which will passed to search
        """
        try:
            print("this is the text that we are passing", text)
            # this will insert value into search bar
            filter_data = self.driver.find_element(
                By.CSS_SELECTOR, f'div.dataTables_filter label input[aria-controls="{element}"]')
            filter_data.send_keys(text)

            time.sleep(2)
            # after search it use to check table records
            try:
                filter_record = self.driver.execute_script(
                'return document.querySelector("#create_td > tbody > tr > td.sorting_1").textContent')
            except:
                print("there is no record on filter")
            try:
                print("this is the filter_record    ", filter_record)
                if filter_record != None:
                    length_filter = 1
                    print("This is the length of filter records :   ", length_filter)
                else:
                    length_filter = 0
            except:
                length_filter = 0
                filter_data.clear()
                filter_data.send_keys(Keys.BACKSPACE)

                print("Filter does not show any record (Filter is not working)")

            data = self.read_result()
            # If the filter is working fine then this will never be empty
            if length_filter != 0:
                print("This filter contains record")
                # Filtering by first value
                if filter_record == text:
                # if filter_record.get_attribute("value") == text:
                    data["UserManagement"][mode_name]["filter"] = "successful"
                    self.update_result(data)
                    print("Values matched")
                    filter_data.clear()
                    filter_data.send_keys(Keys.BACKSPACE)
                    return True
                else:
                    data["UserManagement"][mode_name]["filter"] = "failed"
                    self.update_result(data)
                    print("values not matched")
                    filter_data.clear()
                    filter_data.send_keys(Keys.BACKSPACE)

                    return False
            else:
                data["UserManagement"][mode_name]["filter"] = "failed"
                self.update_result(data)
                print("This filter contains record")
        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            self.existing_data[mode_name]["error"].append("error in fiter functionality")
            print("Error in filter function")

    def check_search(self, text: str, number_col: int, module_name: str):
        """
        element -> string -> which will use to find search element
        text -> string -> Which will passed to search
        """
        try:
            # this will insert value into search bar and we are searching by username
            search_bar = self.driver.find_element(
                By.CSS_SELECTOR, 'input[placeholder="Search..."]')
            search_bar.send_keys(text)

            # press search button
            self.driver.execute_script(
                'document.querySelector(\'input[value="Search"]\').click()')
            time.sleep(4)

            # after search it use to check table records
            search_records = self.driver.execute_script(
                "return document.querySelector('tbody').querySelectorAll('input')")
            try:
                length_search_records = int(len(search_records)/number_col)
                print("This is the length of search records :   ",
                      length_search_records)
            except:
                length_search_records = 0
                search_bar.clear()
                search_bar.send_keys(Keys.BACKSPACE)

                print("No record is found from search")

            # If the record is present that is searched then enter in this condition
            if length_search_records != 0:
                print("This search contains record")

                # search_records[2] this shows that we are picking username of the user that is found after search
                # Also we know that username is unique field
                
                data = self.read_result()
                if search_records[2].get_attribute("value") == text:
                    print("Values matched")
                    time.sleep(2)
                    search_bar.clear()
                    search_bar.send_keys(Keys.BACKSPACE)
                    data["UserManagement"][module_name]["search"] = "successfull"
                    
                    self.update_result(data)
                    # Above shows that record is created successfully
                    # So now delete the created user
                    # It will enter when the module is Configuration
                    if module_name == "config":
                        self.driver.find_element(
                            By.CSS_SELECTOR, "tbody ul.header-dropdown button.btn.btn-default").click()
                        time.sleep(1)
                        self.driver.find_element(
                            By.CSS_SELECTOR, "a[title='click to delete user']").click()
                        time.sleep(1)
                        self.driver.find_element(
                            By.CSS_SELECTOR, "button.confirm").click()
                        time.sleep(1)
                    return True

                # This condition is added or can be delete but write down in case if two records found which is also a bug
                # Possibility that search is not working correctly
                elif length_search_records > 1:
                    print("more than 1 record found")
                    search_bar.clear()
                    search_bar.send_keys(Keys.BACKSPACE)
                    data["UserManagement"][module_name]["search"] = "successfull"
                    self.update_result(data)

                # This shows that record doesn't match with desired value
                # Which also shows that search bar is not working correctly
                else:
                    print("values not matched")
                    search_bar.clear()
                    search_bar.send_keys(Keys.BACKSPACE)
                    self.existing_data["UserManagement"][module_name]["search"] = "failed"
                    self.update_result(self.existing_data)
                    return False
            else:
                self.existing_data["UserManagement"][module_name]["search"] = "failed"
                self.update_result(self.existing_data)
                print("this username is not found")
        except Exception as e:
            print(
                type(e).__name__,  # TypeError
                e.__traceback__.tb_lineno,  # 2
                traceback.format_exc(),
            )
            self.existing_data[module_name]["error"].append("error in search functionality")
            print("Error in search function")

    def read_result(self):
        try:
            with open(RESULT_FILE_NAME, 'r') as file:
                data = json.load(file)
                return data
        except:
            pass

    def update_result(self, data):
        try:
            print("this is data which is present inside update_result   :   ", data)
            with open(RESULT_FILE_NAME, "w") as file:
                json.dump(data, file, indent=4)
                return "successfull"
        except:
            pass